const express = require('express');
const proxy = require('express-http-proxy');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
// 🚀 NEW IMPORTS
const compression = require('compression');
const apicache = require('apicache');
const { channel } = require('diagnostics_channel');

const io = require("socket.io")(3425, {
  cors: { origin: "*" }
});

// ==========================================
// ⚙️ CONFIGURATION
// ==========================================
const USE_HTTPS = false;
const PORT = 7562;
const MY_LOCAL_IP = 'api.viulk.xyz/api';
const DB_API = process.env.DB_API_URL || 'https://db.viulk.xyz';
const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || 'internalapiig';
let homeServerSocket = null;
const channelsjson = 'channels.json';
const epgprogramsjson = 'epg_programs.json';
const MY_PROXY_URL = `${USE_HTTPS ? `https://${MY_LOCAL_IP}:${PORT}` : `https://${MY_LOCAL_IP}`}`;
const TARGET_API_URL = 'https://api1.viu.lk';
const viewsFilePath = './data/view_stats.json';
// Store the cache data in memory
let cachedLicenseUrl = null;
let lastLicenseFetchTime = 0;

// 1 hours in milliseconds (6 hours * 60 mins * 60 secs * 1000 ms)
const CACHE_DURATION_MS = 1 * 60 * 60 * 1000;
// Stores views as { "channel_id": count }
let channelViews = {};
let vodViews = {};
// 🚀 OPTIMIZATION 1: Connection Pooling
const proxyAgent = new https.Agent({
  keepAlive: true,
  maxSockets: 100,
  keepAliveMsecs: 1000,
  timeout: 10000,
  rejectUnauthorized: false
});
const epg_channel_map = [{
  "channel_id": 11,
  "position": 1,
  "order": 0,
  "parental_hidden": false
},
{
  "channel_id": 12,
  "position": 2,
  "order": 1,
  "parental_hidden": false
},
{
  "channel_id": 13,
  "position": 3,
  "order": 2,
  "parental_hidden": false
},
{
  "channel_id": 14,
  "position": 4,
  "order": 3,
  "parental_hidden": false
},
{
  "channel_id": 15,
  "position": 5,
  "order": 4,
  "parental_hidden": false
},
{
  "channel_id": 16,
  "position": 6,
  "order": 5,
  "parental_hidden": false
},
{
  "channel_id": 3,
  "position": 7,
  "order": 6,
  "parental_hidden": false
},
{
  "channel_id": 5,
  "position": 8,
  "order": 7,
  "parental_hidden": false
},
{
  "channel_id": 6,
  "position": 9,
  "order": 8,
  "parental_hidden": false
},
{
  "channel_id": 7,
  "position": 10,
  "order": 9,
  "parental_hidden": false
},
{
  "channel_id": 17,
  "position": 11,
  "order": 10,
  "parental_hidden": false
},
{
  "channel_id": 26,
  "position": 12,
  "order": 11,
  "parental_hidden": false
},
{
  "channel_id": 19,
  "position": 13,
  "order": 12,
  "parental_hidden": false
},
{
  "channel_id": 20,
  "position": 14,
  "order": 13,
  "parental_hidden": false
},
{
  "channel_id": 21,
  "position": 15,
  "order": 14,
  "parental_hidden": false
},
{
  "channel_id": 22,
  "position": 16,
  "order": 15,
  "parental_hidden": false
},
{
  "channel_id": 23,
  "position": 17,
  "order": 16,
  "parental_hidden": false
},
{
  "channel_id": 24,
  "position": 18,
  "order": 17,
  "parental_hidden": false
},
{
  "channel_id": 25,
  "position": 19,
  "order": 18,
  "parental_hidden": false
},
{
  "channel_id": 18,
  "position": 20,
  "order": 19,
  "parental_hidden": false
},
{
  "channel_id": 27,
  "position": 21,
  "order": 20,
  "parental_hidden": false
},
{
  "channel_id": 28,
  "position": 22,
  "order": 21,
  "parental_hidden": false
},
{
  "channel_id": 29,
  "position": 23,
  "order": 22,
  "parental_hidden": false
},
{
  "channel_id": 30,
  "position": 24,
  "order": 23,
  "parental_hidden": false
},
{
  "channel_id": 31,
  "position": 25,
  "order": 24,
  "parental_hidden": false
},
{
  "channel_id": 32,
  "position": 26,
  "order": 25,
  "parental_hidden": false
},
{
  "channel_id": 33,
  "position": 27,
  "order": 26,
  "parental_hidden": false
},
{
  "channel_id": 34,
  "position": 28,
  "order": 27,
  "parental_hidden": false
},
{
  "channel_id": 35,
  "position": 29,
  "order": 28,
  "parental_hidden": false
},
{
  "channel_id": 36,
  "position": 30,
  "order": 29,
  "parental_hidden": false
},
{
  "channel_id": 37,
  "position": 31,
  "order": 30,
  "parental_hidden": false
},
{
  "channel_id": 38,
  "position": 32,
  "order": 31,
  "parental_hidden": false
},
{
  "channel_id": 39,
  "position": 33,
  "order": 32,
  "parental_hidden": false
},
{
  "channel_id": 40,
  "position": 34,
  "order": 33,
  "parental_hidden": false
},
{
  "channel_id": 41,
  "position": 35,
  "order": 34,
  "parental_hidden": false
},
{
  "channel_id": 42,
  "position": 36,
  "order": 35,
  "parental_hidden": false
},
{
  "channel_id": 43,
  "position": 37,
  "order": 36,
  "parental_hidden": false
},
{
  "channel_id": 44,
  "position": 38,
  "order": 37,
  "parental_hidden": false
},
{
  "channel_id": 45,
  "position": 39,
  "order": 38,
  "parental_hidden": false
},
{
  "channel_id": 46,
  "position": 40,
  "order": 39,
  "parental_hidden": false
},
{
  "channel_id": 47,
  "position": 41,
  "order": 40,
  "parental_hidden": false
},
{
  "channel_id": 48,
  "position": 42,
  "order": 41,
  "parental_hidden": false
},
{
  "channel_id": 49,
  "position": 43,
  "order": 42,
  "parental_hidden": false
},
{
  "channel_id": 50,
  "position": 44,
  "order": 43,
  "parental_hidden": false
},
{
  "channel_id": 51,
  "position": 45,
  "order": 44,
  "parental_hidden": false
},
{
  "channel_id": 52,
  "position": 46,
  "order": 45,
  "parental_hidden": false
},
{
  "channel_id": 53,
  "position": 47,
  "order": 46,
  "parental_hidden": false
},
{
  "channel_id": 54,
  "position": 48,
  "order": 47,
  "parental_hidden": false
},
{
  "channel_id": 55,
  "position": 49,
  "order": 48,
  "parental_hidden": false
},
{
  "channel_id": 56,
  "position": 50,
  "order": 49,
  "parental_hidden": false
},
{
  "channel_id": 57,
  "position": 51,
  "order": 50,
  "parental_hidden": false
},
{
  "channel_id": 58,
  "position": 52,
  "order": 51,
  "parental_hidden": false
},
{
  "channel_id": 68,
  "position": 53,
  "order": 52,
  "parental_hidden": false
},
{
  "channel_id": 2086,
  "position": 54,
  "order": 53,
  "parental_hidden": false
},
{
  "channel_id": 61,
  "position": 55,
  "order": 54,
  "parental_hidden": false
},
{
  "channel_id": 62,
  "position": 56,
  "order": 55,
  "parental_hidden": false
},
{
  "channel_id": 63,
  "position": 57,
  "order": 56,
  "parental_hidden": false
},
{
  "channel_id": 64,
  "position": 58,
  "order": 57,
  "parental_hidden": false
},
{
  "channel_id": 2,
  "position": 59,
  "order": 58,
  "parental_hidden": false
},
{
  "channel_id": 60,
  "position": 60,
  "order": 59,
  "parental_hidden": false
},
{
  "channel_id": 67,
  "position": 61,
  "order": 60,
  "parental_hidden": false
},
{
  "channel_id": 2126,
  "position": 62,
  "order": 61,
  "parental_hidden": false
},
{
  "channel_id": 70,
  "position": 63,
  "order": 62,
  "parental_hidden": false
},
{
  "channel_id": 71,
  "position": 64,
  "order": 63,
  "parental_hidden": false
},
{
  "channel_id": 72,
  "position": 65,
  "order": 64,
  "parental_hidden": false
},
{
  "channel_id": 73,
  "position": 66,
  "order": 65,
  "parental_hidden": false
},
{
  "channel_id": 74,
  "position": 67,
  "order": 66,
  "parental_hidden": false
},
{
  "channel_id": 75,
  "position": 68,
  "order": 67,
  "parental_hidden": false
},
{
  "channel_id": 76,
  "position": 69,
  "order": 68,
  "parental_hidden": false
},
{
  "channel_id": 77,
  "position": 70,
  "order": 69,
  "parental_hidden": false
},
{
  "channel_id": 78,
  "position": 71,
  "order": 70,
  "parental_hidden": false
},
{
  "channel_id": 79,
  "position": 72,
  "order": 71,
  "parental_hidden": false
},
{
  "channel_id": 80,
  "position": 73,
  "order": 72,
  "parental_hidden": false
},
{
  "channel_id": 81,
  "position": 74,
  "order": 73,
  "parental_hidden": false
},
{
  "channel_id": 82,
  "position": 75,
  "order": 74,
  "parental_hidden": false
},
{
  "channel_id": 83,
  "position": 76,
  "order": 75,
  "parental_hidden": false
},
{
  "channel_id": 84,
  "position": 77,
  "order": 76,
  "parental_hidden": false
},
{
  "channel_id": 85,
  "position": 78,
  "order": 77,
  "parental_hidden": false
},
{
  "channel_id": 86,
  "position": 79,
  "order": 78,
  "parental_hidden": false
},
{
  "channel_id": 87,
  "position": 80,
  "order": 79,
  "parental_hidden": false
},
{
  "channel_id": 88,
  "position": 81,
  "order": 80,
  "parental_hidden": false
},
{
  "channel_id": 89,
  "position": 82,
  "order": 81,
  "parental_hidden": false
},
{
  "channel_id": 90,
  "position": 83,
  "order": 82,
  "parental_hidden": false
},
{
  "channel_id": 91,
  "position": 84,
  "order": 83,
  "parental_hidden": false
},
{
  "channel_id": 92,
  "position": 85,
  "order": 84,
  "parental_hidden": false
},
{
  "channel_id": 93,
  "position": 86,
  "order": 85,
  "parental_hidden": false
},
{
  "channel_id": 94,
  "position": 87,
  "order": 86,
  "parental_hidden": false
},
{
  "channel_id": 95,
  "position": 88,
  "order": 87,
  "parental_hidden": false
},
{
  "channel_id": 96,
  "position": 89,
  "order": 88,
  "parental_hidden": false
},
{
  "channel_id": 97,
  "position": 90,
  "order": 89,
  "parental_hidden": false
},
{
  "channel_id": 98,
  "position": 91,
  "order": 90,
  "parental_hidden": false
},
{
  "channel_id": 99,
  "position": 92,
  "order": 91,
  "parental_hidden": false
},
{
  "channel_id": 100,
  "position": 93,
  "order": 92,
  "parental_hidden": false
},
{
  "channel_id": 101,
  "position": 94,
  "order": 93,
  "parental_hidden": false
},
{
  "channel_id": 102,
  "position": 95,
  "order": 94,
  "parental_hidden": false
},
{
  "channel_id": 103,
  "position": 96,
  "order": 95,
  "parental_hidden": false
},
{
  "channel_id": 104,
  "position": 97,
  "order": 96,
  "parental_hidden": false
},
{
  "channel_id": 105,
  "position": 98,
  "order": 97,
  "parental_hidden": false
},
{
  "channel_id": 106,
  "position": 99,
  "order": 98,
  "parental_hidden": false
},
{
  "channel_id": 107,
  "position": 100,
  "order": 99,
  "parental_hidden": false
},
{
  "channel_id": 108,
  "position": 101,
  "order": 100,
  "parental_hidden": false
},
{
  "channel_id": 109,
  "position": 102,
  "order": 101,
  "parental_hidden": false
},
{
  "channel_id": 110,
  "position": 103,
  "order": 102,
  "parental_hidden": false
},
{
  "channel_id": 111,
  "position": 104,
  "order": 103,
  "parental_hidden": false
},
{
  "channel_id": 112,
  "position": 105,
  "order": 104,
  "parental_hidden": false
},
{
  "channel_id": 113,
  "position": 106,
  "order": 105,
  "parental_hidden": false
},
{
  "channel_id": 69,
  "position": 107,
  "order": 106,
  "parental_hidden": false
},
{
  "channel_id": 59,
  "position": 108,
  "order": 107,
  "parental_hidden": false
},
{
  "channel_id": 8,
  "position": 109,
  "order": 108,
  "parental_hidden": false
},
{
  "channel_id": 116,
  "position": 110,
  "order": 109,
  "parental_hidden": false
},
{
  "channel_id": 117,
  "position": 111,
  "order": 110,
  "parental_hidden": false
},
{
  "channel_id": 118,
  "position": 112,
  "order": 111,
  "parental_hidden": false
},
{
  "channel_id": 119,
  "position": 113,
  "order": 112,
  "parental_hidden": false
},
{
  "channel_id": 120,
  "position": 114,
  "order": 113,
  "parental_hidden": false
},
{
  "channel_id": 121,
  "position": 115,
  "order": 114,
  "parental_hidden": false
},
{
  "channel_id": 122,
  "position": 116,
  "order": 115,
  "parental_hidden": false
},
{
  "channel_id": 123,
  "position": 117,
  "order": 116,
  "parental_hidden": false
},
{
  "channel_id": 124,
  "position": 118,
  "order": 117,
  "parental_hidden": false
},
{
  "channel_id": 125,
  "position": 119,
  "order": 118,
  "parental_hidden": false
},
{
  "channel_id": 126,
  "position": 120,
  "order": 119,
  "parental_hidden": false
},
{
  "channel_id": 127,
  "position": 121,
  "order": 120,
  "parental_hidden": false
},
{
  "channel_id": 128,
  "position": 122,
  "order": 121,
  "parental_hidden": false
},
{
  "channel_id": 129,
  "position": 123,
  "order": 122,
  "parental_hidden": false
},
{
  "channel_id": 130,
  "position": 124,
  "order": 123,
  "parental_hidden": false
},
{
  "channel_id": 131,
  "position": 125,
  "order": 124,
  "parental_hidden": false
},
{
  "channel_id": 132,
  "position": 126,
  "order": 125,
  "parental_hidden": false
},
{
  "channel_id": 133,
  "position": 127,
  "order": 126,
  "parental_hidden": false
},
{
  "channel_id": 2085,
  "position": 128,
  "order": 127,
  "parental_hidden": false
},
{
  "channel_id": 2236,
  "position": 129,
  "order": 128,
  "parental_hidden": false
},
{
  "channel_id": 1831,
  "position": 131,
  "order": 129,
  "parental_hidden": false
},
{
  "channel_id": 1833,
  "position": 133,
  "order": 130,
  "parental_hidden": false
},
{
  "channel_id": 1834,
  "position": 134,
  "order": 131,
  "parental_hidden": false
},
{
  "channel_id": 1835,
  "position": 135,
  "order": 132,
  "parental_hidden": false
},
{
  "channel_id": 1836,
  "position": 136,
  "order": 133,
  "parental_hidden": false
},
{
  "channel_id": 1837,
  "position": 137,
  "order": 134,
  "parental_hidden": false
}];
const channelMap = {
  "channelone": "Ch001", "rupavahini": "Ch002", "nethratv": "Ch003", "itn": "Ch004",
  "vasanthamtv": "Ch005", "tvderana": "Ch006", "swarnavahini": "Ch007", "sirasatv": "Ch008",
  "shakthitv": "Ch009", "tv1": "Ch010", "hirutv": "Ch011", "supreme": "Ch012",
  "arttelevision": "Ch013", "adaderana24": "Ch014", "siyathatv": "Ch015", "harithatv": "Ch016",
  "tvdidula": "Ch017", "rideetv": "Ch018", "citihitz": "Ch019", "rangiri": "Ch021",
  "hitv": "Ch022", "pragna": "Ch023", "damsathara": "Ch024", "jayatv": "Ch025",
  "buddhisttv": "Ch026", "shraddhatv": "Ch027", "godtv": "Ch028", "ewtn": "Ch029",
  "aljazeera": "Ch030", "abcaustralia": "Ch031", "bbcworld": "Ch032", "CGTN": "Ch033",
  "cnn": "Ch034", "ndtv": "Ch035", "france24": "Ch036", "euronews": "Ch037",
  "bloomberg": "Ch038", "cnbc": "Ch039", "B4UMusic": "Ch040", "romantico": "Ch041",
  "channelc": "Ch042", "jayamax": "Ch043", "zingtv": "Ch044", "davinci": "Ch045",
  "cbeebies": "Ch046", "cartoonnetwork": "Ch047", "aplus": "Ch048", "nickelodeon": "Ch049",
  "babytv": "Ch050", "disneyjr": "Ch051", "nickjr": "Ch052", "moonbug": "Ch053",
  "pogo": "Ch054", "animalplanet": "Ch055", "discovery": "Ch056", "discoveryscience": "Ch057",
  "tlc": "Ch058", "natgeo": "Ch059", "ngcwild": "Ch060", "historytv18": "Ch061",
  "paparetv1": "Ch062", "paparesd": "Ch063", "sonysports1": "Ch064", "tencricket": "Ch065",
  "sonysports2": "Ch066", "eurosport": "Ch067", "starsports1": "Ch208", "starsports2": "Ch069",
  "hbosignature": "Ch070", "hbofamily": "Ch071", "andflix": "Ch072", "hitsmovies": "Ch073",
  "sonypix": "Ch074", "hits": "Ch075", "zeecafe": "Ch076", "warnertv": "Ch077",
  "axn": "Ch078", "colorsinfinity": "Ch079", "fashiontv": "Ch080", "disneyint": "Ch081",
  "comedyzone": "Ch082", "bbcearth": "Ch083", "starbharath": "Ch084", "sonyset": "Ch085",
  "setmax": "Ch086", "stargold": "Ch087", "colors": "Ch088", "starplus": "Ch089",
  "b4umovies": "Ch090", "stargoldromance": "Ch091", "zeecinema": "Ch092", "colorstamil": "Ch093",
  "jayatvind": "Ch094", "jayamovies": "Ch095", "starvijay": "Ch096", "kalaignartv": "Ch097",
  "zeetamil": "Ch098", "siripollitv": "Ch099", "jayaplus": "Ch100", "zeethirai": "Ch101",
  "nenasasinhalaal": "Ch102", "nenasasinhalagrade6to9": "Ch103", "nenasatamilal": "Ch104",
  "nenasasinhalaol": "Ch105", "nenasatamilol": "Ch106", "hgtv": "Ch107", "foodnetwork": "Ch108",
  "discoveryhdworld": "Ch109", "animalplanethd": "Ch110", "axnhd": "Ch111",
  "rockentertainmenthd": "Ch112", "hitsnow": "Ch113", "hbohd": "Ch114", "starmovieshd": "Ch115",
  "cinemaworldhd": "Ch116", "cinemaxhd": "Ch117", "hbohitshd": "Ch118",
  "starmoviesselecthd": "Ch119", "starsportshd1": "Ch120", "starsselecthd1": "Ch121",
  "starsselecthd2": "Ch122", "sonysports2hd": "Ch123", "sonysports5hd": "Ch124",
  "premiersports": "Ch125", "thepaparehd": "Ch126", "thepapare2hd": "Ch127",
  "mobeventchannel": "Ch139", "trtworld": "Ch146", "dwenglish": "Ch151", "raiitalia": "Ch148",
  "phoenixinfo": "Ch150", "tv5monde": "Ch147", "colorsrishty": "Ch152", "channel20": "Ch020",
  "discoveryturbo": "Ch213", "eventchannel2": "",
};
const proxyRoutes = [
  // --- Existing Routes ---
  { method: 'get', url: '/api/client/v2/default/client_translations' },
  { method: 'get', url: '/api/client/v1/default/skins' },
  //{ method: 'get',  url: '/api/client/v1/default/client_configuration' },

  // Icon packs (Handles "1" or any other pack ID)
  { method: 'get', url: '/api/client/v1/default/icon_packs/:packid/ttf' },
  { method: 'get', url: '/api/client/v1/default/icon_packs/:packid/codepoint' },

  // Global Configs
  { method: 'get', url: '/api/client/v1/global/currencies' },
  { method: 'get', url: '/api/client/v1/global/languages' },
  { method: 'get', url: '/api/client/v1/default/services' },

  // User Specific Endpoints

  //{ method: 'get',  url: '/api/client/v1/default/users/:userid/info' },
  //{ method: 'get',  url: '/api/client/v1/default/users/:userid' },

];
const app = express();
let cache = apicache.middleware;


// ==========================================
// 🚀 OPTIMIZATION 3: COMPRESSION (GZIP)
// ==========================================
// Shrink all text/json responses by ~80%
app.use(compression());

// ─── IP BAN CACHE ──────────────────────────────────────────────────────────────
/** @type {Map<string, string>} */
const ipBanCache = new Map();

const refreshIpBans = async () => {
  if (!INTERNAL_API_KEY) return;
  try {
    const res = await fetch(`${DB_API}/ip-bans/list`, {
      headers: { 'x-internal-key': INTERNAL_API_KEY },
    });
    if (!res.ok) return;
    const bans = await res.json();
    ipBanCache.clear();
    for (const { ip, reason } of bans) {
      ipBanCache.set(ip, reason || 'Banned');
    }
  } catch (err) {
    console.error('[ip-ban] Failed to refresh ban list:', err.message);
  }
};

refreshIpBans();
setInterval(refreshIpBans, 60_000);

app.use((req, res, next) => {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  const raw = forwarded || req.socket?.remoteAddress || '';
  const ip = raw.startsWith('::ffff:') ? raw.slice(7) : raw;
  if (ip && ipBanCache.has(ip)) {
    return res.status(403).json({
      error: 'You have been banned. Check out ztube.viulk.xyz/banned for more info.',
      banned: true,
    });
  }
  next();
});

// ==========================================
// 📺 EPG XML PROXY ROUTE
// ==========================================

io.on("connection", (socket) => {
  console.log(`Home Server connected! ID: ${socket.id}`);
  const token = socket.handshake.auth.token;
  if (token !== "socketpass") {
    socket.disconnect();
    return;
  }
  homeServerSocket = socket;
  socket.on("disconnect", () => {
    console.log("Home Server disconnected.");
    homeServerSocket = null;
  });
});

// ==========================================
// 🛠️ RESPONSE MODIFIERS
// ==========================================
const RES_BODY_MODIFICATIONS = [
  {
    pattern: /\/api\/client\/v1\/default\/users\/\d+\/packages/,
    modifier: (json) => {
      if (json && Array.isArray(json.data)) {
        json.data = json.data.map(item => ({ ...item, purchased: "2035-06-01T00:00:00Z" }));
      }
      return json;
    }
  },
  {
    pattern: '/api/client/v1/default/proxy_url',
    modifier: (json) => {
      if (json && json.data) json.data.url = MY_PROXY_URL;
      return json;
    }
  },
  {
    pattern: /^\/api\/client\/v1\/default\/users\/\d+\/movies\/\d+$/,
    modifier: (json) => {
      if (json && json.data) {
        json.data.purchased = true;
        json.data.purchased_till = "2035-06-01T00:00:00Z";
      }
      return json;
    }
  },
  {
    pattern: /^\/api\/client\/v1\/default\/users\/\d+\/series\/\d+$/,
    modifier: (json) => {
      if (json && json.data) {
        json.data.purchased = true;
        json.data.purchased_till = "2035-06-01T00:00:00Z";
      }
      return json;
    }
  },
  {
    // Replace did_url, redirect_url, and enforce versions
    pattern: /\/api\/client\/v1\/default\/client_configuration/,
    modifier: (json) => {
      console.log('🔗 Replacing URLs and Versions recursively (including stringified JSON)...');

      const newDidUrl = "https://web.viulk.xyz/otp-login?dialogsuck";
      const newRedirectUrl = "https://web.viulk.xyz";
      const targetVersion = "15.40.1";

      const replaceRecursive = (obj) => {
        if (Array.isArray(obj)) {
          obj.forEach(item => replaceRecursive(item));
        } else if (typeof obj === 'object' && obj !== null) {
          for (const key in obj) {
            const val = obj[key];

            // 1. Direct match: Check for specific keys
            if (key === 'did_url') {
              obj[key] = newDidUrl;
            }
            else if (key === 'redirect_url') {
              obj[key] = newRedirectUrl;
            }
            // ✅ NEW: Handle version keys
            else if (key === 'required_version' || key === 'recommended_version') {
              obj[key] = targetVersion;
            }

            // 2. Normal recursion: It's a standard object/array
            else if (typeof val === 'object' && val !== null) {
              replaceRecursive(val);
            }

            // 3. Stringified JSON: Check if string contains ANY of the target keys
            else if (typeof val === 'string' && (
              val.includes('did_url') ||
              val.includes('redirect_url') ||
              val.includes('required_version') ||
              val.includes('recommended_version')
            )) {
              try {
                let parsed = JSON.parse(val);
                replaceRecursive(parsed);
                obj[key] = JSON.stringify(parsed);
              } catch (e) {
                // Parsing failed, ignore
              }
            }
          }
        }
      };

      replaceRecursive(json);
      return json;
    }
  },
];

// ==========================================
// 1. MIDDLEWARE (CORS) - LIGHTWEIGHT
// ==========================================
app.use((req, res, next) => {
  // 1. Get the origin from the request
  const origin = req.headers.origin;

  // 2. If an origin is present, reflect it back.
  // If no origin is present (e.g. server-to-server calls), usually no CORS header is needed,
  // or you can set it to '*' just in case.
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  } else {
    // Optional: Allow non-browser requests (like Postman or mobile apps)
    // that don't send an Origin header to pass through generic checks.
    res.setHeader('Access-Control-Allow-Origin', '*');
  }

  // 3. Crucial: Tell proxies/browsers that the response varies based on the Origin
  res.setHeader('Vary', 'Origin');

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');

  // 4. Handle requested headers dynamically
  const requestedHeaders = req.headers['access-control-request-headers'];
  if (requestedHeaders) {
    res.setHeader('Access-Control-Allow-Headers', requestedHeaders);
  }

  // 5. Allow Credentials (cookies, auth headers)
  // Note: This requires the Origin to be explicit (not '*'), which is why we reflected it above.
  res.setHeader('Access-Control-Allow-Credentials', 'true');

  // 6. Handle Preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }

  // 7. Nginx Strip Fix
  if (req.url.startsWith('/api/')) {
    req.url = req.url.replace('/api/', '/');
  }

  next();
});
// 🚀 OPTIMIZATION 2: Removed Global Body Parser
// We only apply body parser to the specific routes that actually need it.
const jsonParser = bodyParser.json({ limit: '10mb' });
const urlEncodedParser = bodyParser.urlencoded({ extended: true, limit: '10mb' });
const mockMiddleware = [jsonParser, urlEncodedParser];

// ==========================================
// ⚡ MOCK ROUTES
// ==========================================

// Helper function to fetch the reason from the API
const getReason = async () => {
  try {
    const response = await fetch('https://naas.isalman.dev/no');
    return await response.json();
  } catch (error) {
    // Fallback in case the external API is down
    return { reason: "An unknown error occurred." };
  }
};

// 1. Global Cache Variables
let cachedChannels = [];
let cachedPrograms = [];
let epgMapping = {};
let cachedVods = [];
let showVods = []
const loadViewsFromDisk = () => {
  try {
    if (fs.existsSync(viewsFilePath)) {
      const data = JSON.parse(fs.readFileSync(viewsFilePath, 'utf-8'));
      channelViews = data.channelViews || {};
      vodViews = data.vodViews || {};
      console.log('✅ View stats loaded from disk');
    }
  } catch (err) {
    console.error('⚠️ Failed to load view stats:', err);
  }
};

// 3. Save function
const saveViewsToDisk = () => {
  try {
    const data = JSON.stringify({ channelViews, vodViews }, null, 2);
    fs.writeFileSync(viewsFilePath, data);
    console.log(`💾 Stats autosaved at ${new Date().toLocaleTimeString()}`);
  } catch (err) {
    console.error('❌ Failed to save view stats:', err);
  }
};

// Start the process
loadViewsFromDisk();
// Save data before the process exits
process.on('SIGINT', () => {
  console.log('Final save before shutdown...');
  saveViewsToDisk();
  process.exit();
});
// Save every 5 minutes (300,000 ms)
setInterval(saveViewsToDisk, 5 * 60 * 1000);
const refreshVodCache = () => {
  try {
    const internalData = JSON.parse(fs.readFileSync('./vod_data/INTERNAL.json', 'utf-8'));
    const lionsgateData = JSON.parse(fs.readFileSync('./vod_data/LIONSGATE.json', 'utf-8'));

    // Combine arrays
    const combined = [...internalData, ...lionsgateData];

    // Sort: Newest to Oldest
    combined.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    cachedVods = combined;
    refreshShowVodCache(); // Also refresh shows whenever movies are refreshed
    console.log(`VOD Cache updated: ${cachedVods.length} movies loaded.`);
  } catch (err) {
    console.error('Error refreshing VOD cache:', err);
  }
};
const refreshShowVodCache = () => {
  try {
    const internalData = JSON.parse(fs.readFileSync('./vod_data/shows/INTERNAL.json', 'utf-8'));
    const lionsgateData = JSON.parse(fs.readFileSync('./vod_data/shows/LIONSGATE.json', 'utf-8'));

    // Combine arrays
    const combined = [...internalData, ...lionsgateData];

    // Sort: Newest to Oldest
    combined.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    showVods = combined;
    console.log(`Show VOD Cache updated: ${showVods.length} shows loaded.`);
  } catch (err) {
    console.error('Error refreshing Show VOD cache:', err);
  }
};

// Initial load and refresh every 30 mins
refreshVodCache();
setInterval(refreshVodCache, 30 * 60 * 1000);
// 2. Function to refresh cache from disk
const refreshEpgCache = () => {
  try {
    const channelsData = fs.readFileSync(channelsjson, 'utf-8');
    const epgData = fs.readFileSync(epgprogramsjson, 'utf-8');

    cachedChannels = JSON.parse(channelsData);
    cachedPrograms = JSON.parse(epgData);

    // Pre-calculate mapping so we don't do it inside the request
    epgMapping = Object.fromEntries(
      epg_channel_map.map(m => [m.position, m.channel_id])
    );

    console.log(`Cache refreshed at ${new Date().toISOString()}`);
  } catch (err) {
    console.error('Failed to refresh EPG cache:', err);
  }
};

// 3. Initial load and set interval (e.g., every 5 minutes)
refreshEpgCache();
setInterval(refreshEpgCache, 5 * 60 * 1000);
app.get('/status', (req, res) => {
  const isOnline = homeServerSocket !== null && homeServerSocket.connected;

  res.json({
    status: isOnline ? "online" : "offline",
    lastChecked: new Date().toISOString(),
    uptime: process.uptime(),
  });
});
// Rate limiter for reports: one per IP every 5 minutes
const reportRateLimiter = new Map();

app.post('/report', (req, res) => {
  // 1. Get client IP
  let clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || req.ip;
  if (clientIp && clientIp.includes(',')) {
    clientIp = clientIp.split(',')[0].trim();
  }
  if (clientIp && clientIp.includes('::ffff:')) {
    clientIp = clientIp.split(':').pop();
  }

  // 2. Check rate limit
  const now = Date.now();
  const lastReportTime = reportRateLimiter.get(clientIp);
  const RATE_LIMIT_MS = 5 * 60 * 1000; // 5 minutes

  if (lastReportTime && (now - lastReportTime) < RATE_LIMIT_MS) {
    const secondsRemaining = Math.ceil((RATE_LIMIT_MS - (now - lastReportTime)) / 1000);
    return res.status(429).json({ 
      error: `Rate limited. Please wait ${secondsRemaining} seconds before submitting another report.` 
    });
  }

  let body = '';

  // 3. Collect the data chunks as they arrive
  req.on('data', (chunk) => {
    body += chunk.toString();

    // Safety: If someone tries to flood the server, kill the connection at 1MB
    if (body.length > 1e6) {
      req.destroy();
    }
  });

  // 4. Once the stream ends, process the data
  req.on('end', async () => {
    try {
      // Check if we actually got data
      if (!body) {
        return res.status(400).json({ error: "No data received" });
      }
      lastLicenseFetchTime = 0; // Force refresh of license data on next request
      const reportData = JSON.parse(body);
      const webhookUrl = 'https://discord.com/api/webhooks/1477194945981841419/XnNCIO7YLoo08-RdWVtU6iAPRxnIV8QD6n5IEKSE1X4aL4DYEYipJg_b5Ah8TB1SX9_R';

      // 5. Setup the Embed
      const type = reportData?.type || 'unknown_report';
      const embedColor = type === 'outage' ? 15158332 : 15105570;

      const embed = {
        title: `🚨 New Report: ${type.toUpperCase().replace('_', ' ')}`,
        color: embedColor,
        fields: [
          { name: "Client IP", value: clientIp, inline: true }
        ],
        footer: { text: `User Agent: ${reportData?.userAgent || 'Unknown'}` },
        timestamp: reportData?.timestamp || new Date().toISOString()
      };

      // Add fields dynamically
      if (reportData.videoId) embed.fields.push({ name: "Video ID", value: reportData.videoId, inline: true });
      if (reportData.videoTitle) embed.fields.push({ name: "Title", value: reportData.videoTitle, inline: true });
      if (reportData.contentType) embed.fields.push({ name: "Content Type", value: reportData.contentType, inline: true });
      if (reportData.page) embed.fields.push({ name: "Page Location", value: reportData.page, inline: true });

      // 6. Send to Discord
      const discordResponse = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [embed]
        })
      });

      // 7. Update rate limiter only on successful processing
      reportRateLimiter.set(clientIp, now);

      res.json({ status: "ok" });

    } catch (err) {
      console.error('Report processing error:', err.message);
      res.status(400).json({ error: "Invalid JSON format" });
    }
  });

  req.on('error', (err) => {
    console.error('Request stream error:', err);
    res.status(500).end();
  });
});
app.get('/epg/xml', (req, res) => {
  const epgUrl = 'https://tivi.viulk.xyz/metadata/epg.xml';

  https.get(epgUrl, (upstream) => {
    if (upstream.statusCode && upstream.statusCode >= 400) {
      res.status(upstream.statusCode).send('Upstream error');
      return;
    }

    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    upstream.pipe(res);
  }).on('error', (err) => {
    console.error('EPG XML proxy error:', err);
    res.status(500).send('EPG proxy failed');
  });
});
app.post('/epg/upload', (req, res) => {
  // 1. Authorization Check
  const authHeader = req.headers.authorization;
  if (authHeader !== 'Bearer 2784617864768') {
    console.error('Unauthorized EPG upload attempt');
    return res.status(401).json({ error: 'Unauthorized' });
  }

  console.log('Starting EPG stream upload...');

  // 2. Create a Write Stream to overwrite the existing file
  const fileStream = fs.createWriteStream(epgprogramsjson);

  // 3. Pipe the incoming request stream directly to the file
  req.pipe(fileStream);

  fileStream.on('finish', () => {
    console.log('✅ EPG file successfully written to disk.');

    // 4. Refresh the in-memory cache so the API uses the new data immediately
    try {
      refreshEpgCache();
      res.json({ status: 'ok', message: 'EPG uploaded and cache refreshed' });
    } catch (err) {
      console.error('Error refreshing cache after upload:', err);
      res.status(500).json({ status: 'partial_success', message: 'File saved but cache refresh failed' });
    }
  });

  fileStream.on('error', (err) => {
    console.error('File Stream Error:', err);
    res.status(500).json({ error: 'Failed to write EPG file' });
  });
});
app.get('/channels', (req, res) => {
  const now = new Date();

  const enrichedChannels = cachedChannels.map(channel => {
    const realEpgId = epgMapping[channel.epgID] || channel.epgID;

    // 1. Gather ALL programs currently active on this channel
    const activePrograms = cachedPrograms.filter(pg => {
      if (pg.channel_id != realEpgId) return false;
      return now >= new Date(pg.start) && now <= new Date(pg.end);
    });

    // 2. Pick the best candidate from the active programs
    let currentProgram = null;
    
    if (activePrograms.length > 0) {
      // Try to find one that IS NOT generic filler
      currentProgram = activePrograms.find(pg => 
        pg.title !== "Program" && pg.title !== "Filler"
      );

      // If it's still null, it means the ONLY thing playing is "Program" or "Filler".
      // In that case, we just take the first available slot.
      if (!currentProgram) {
        currentProgram = activePrograms[0];
      }
    }

    const imageId = currentProgram?.image_id || 683753;
    const viewsCount = channelViews[channel.id] || 0;
    
    return {
      ...channel,
      realepgId: realEpgId,
      title: currentProgram ? currentProgram.title : (channel.name || 'No Program Info'),
      thumbnail: `https://api3.viu.lk/api/client/v1/global/images/${imageId}?accessKey=WkVjNWNscFhORDBLCg==`,
      views: `${viewsCount} view${viewsCount !== 1 ? 's' : ''}`,
      time: 'LIVE',
      isLive: true,
      manifest: `https://api.viulk.xyz/api/api/client/v1/default/users/69/live/channels/${channel.id}`
    };
  });

  res.json(enrichedChannels);
});
//send all programs for the past 3 days and next 3 days to the client so that it can do client side filtering and reduce load on the server
app.get('/epg/:epgId', (req, res) => {
  const epgId = parseInt(req.params.epgId, 10); //epg id is correct this time no need to find realchannelid
  const now = new Date();
  const threeDaysAgo = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
  const threeDaysLater = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

  const programsForEpg = cachedPrograms.filter(pg => {
    if (pg.channel_id !== epgId) return false;
    const programStart = new Date(pg.start);
    const programEnd = new Date(pg.end);
    pg.realepgId = epgId;
    //lets also edit the program object to add a isLive property so that client can easily show live badge on the program card
    pg.isLive = now >= programStart && now <= programEnd;
    pg.time = `${programStart.getHours().toString().padStart(2, '0')}:${programStart.getMinutes().toString().padStart(2, '0')} - ${programEnd.getHours().toString().padStart(2, '0')}:${programEnd.getMinutes().toString().padStart(2, '0')}`;
    //logic to turn epgId back to channelid from json and add manifest url to the program object
    pg.views = `${channelViews[pg.channel_id] || 0} view${(channelViews[pg.channel_id] || 0) !== 1 ? 's' : ''}`;
    const channelidfromepg = Object.entries(epgMapping).find(([pos, id]) => id === epgId)?.[0] || epgId;
    const channelidfromjson = cachedChannels.find(ch => ch.epgID === channelidfromepg)?.id || channelidfromepg;
    pg.manifest = `https://api.viulk.xyz/api/api/client/v1/default/users/:userid/:eventmo/channels/${channelidfromjson}/shows/${pg.id}`;
    return (programStart >= threeDaysAgo && programStart <= threeDaysLater) ||
      (programEnd >= threeDaysAgo && programEnd <= threeDaysLater) ||
      (programStart <= threeDaysAgo && programEnd >= threeDaysLater); // Programs that started before and end after the window
  });

  res.json(programsForEpg);
});
const WIDEVINE_SYSTEM_ID = Buffer.from('edef8ba979d64acea3c827dcd51d21ed', 'hex');

function extractPsshFromBuffer(buffer) {
  let offset = 0;
  const psshs = [];
  while (true) {
    const idx = buffer.indexOf('pssh', offset);
    if (idx === -1) break;

    if (idx >= 4 && idx + 24 <= buffer.length) {
      const size = buffer.readUInt32BE(idx - 4);
      const systemId = buffer.subarray(idx + 8, idx + 24);

      if (systemId.equals(WIDEVINE_SYSTEM_ID) && (idx - 4 + size) <= buffer.length) {
        const psshBox = buffer.subarray(idx - 4, idx - 4 + size);
        psshs.push(psshBox.toString('base64')); // Typo fixed!
      }
    }
    offset = idx + 4;
  }
  return psshs;
}

app.get('/api/live/:channel', async (req, res) => {
  // Convert to string and pad to 3 digits with '0'
  const paddedNumber = req.params.channel.toString().padStart(3, '0');
  const channelnum = `Ch${paddedNumber}`;

  if (!req.params.channel) return res.status(404).json({ error: 'Channel not found' });

  const manifestResponse = await askForManifest(`https://bpcdn.dialog.lk/bpk-tv/${channelnum}/out/index.mpd`);

  if (!manifestResponse) {
    return res.status(503).json({ status: "error", message: "Server is offline or timed out" });
  }
  const choices = [5, 6, 8];
  let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

  // 5. Safety Check: Did any CDN node actually work?
  if (!workingUrl) {
    workingUrl = manifestResponse.manifest;
  }

  res.redirect(307, workingUrl);
});
app.get('/m3u/:channelnum', async (req, res) => {
  const channel = req.params.channelnum.replace(/\.mpd$/i, '');
  const { begin, end } = req.query;
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  let targetUrl = `https://bpcdn.dialog.lk/bpk-tv/${channel}/out/index.mpd`;

  if (begin && end) {
    const nowInSeconds = Math.floor(Date.now() / 1000);
    let finalEnd = Number(end);

    // If the requested end time is in the future,
    // cap it at current time minus 60 seconds.
    const offset = 40;
    if (finalEnd > (nowInSeconds - offset)) {
      finalEnd = nowInSeconds - offset;
    }
    targetUrl += `?begin=${begin}&end=${finalEnd}`;

    try {
      // 1. Fetch the original manifest (this will follow the redirect automatically)
      //const mpdRes = await fetch(targetUrl);
      //if (!mpdRes.ok) throw new Error(`Failed to fetch MPD: ${mpdRes.status}`);
      //let mpdText = await mpdRes.text();
      const manifestResponse = await askForManifest(targetUrl);

      if (!manifestResponse) {
        return res.status(503).json({ status: "error", message: "Server is offline or timed out" });
      }
      const choices = [5, 6, 8];
      let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

      if (!workingUrl) {
        workingUrl = manifestResponse.manifest;
      }
      const mpdRes = await fetch(workingUrl);
      if (!mpdRes.ok) throw new Error(`Failed to fetch MPD: ${mpdRes.status}`);
      let mpdText = await mpdRes.text();
      // The magic variable: This contains the FINAL url (e.g., bpcdncs1.dialog.lk)
      const finalUrl = mpdRes.url;

      // 1.5 Parse the MPD's BaseURL so our server knows exactly where the chunks live
      let currentBaseUrl = finalUrl.substring(0, finalUrl.lastIndexOf('/') + 1);
      const baseMatch = /<BaseURL>(.*?)<\/BaseURL>/i.exec(mpdText);
      if (baseMatch) {
        // If the MPD says "dash/", we append it to the final CDN url
        currentBaseUrl = new URL(baseMatch[1], currentBaseUrl).toString();
      }

      // 2. Parse out the first Media Segment URL
      const repIdMatch = /<Representation[^>]*id="([^"]+)"/.exec(mpdText);
      const repId = repIdMatch ? repIdMatch[1] : "";

      let mediaUrl = null;
      const asetMatches = mpdText.split('<AdaptationSet');

      for (let i = 1; i < asetMatches.length; i++) {
        const aset = asetMatches[i];
        const m = /media="([^"]+)"/.exec(aset);
        if (m) {
          let path = m[1].replace("$RepresentationID$", repId);

          // FIX: Added \s+ to ensure we strictly match the <S> tag and not <SegmentTemplate>
          const tMatch = /<S\s+[^>]*?t="(\d+)"/.exec(aset);
          const numMatch = /startNumber="(\d+)"/.exec(aset);

          if (path.includes("$Time$") && tMatch) {
            path = path.replace("$Time$", tMatch[1]);
          } else if (path.includes("$Number$")) {
            path = path.replace("$Number$", numMatch ? numMatch[1] : "1");
          }

          mediaUrl = new URL(path, currentBaseUrl).toString();
          break;
        }
      }

      let realPssh = null;
      if (mediaUrl) {
        const segRes = await fetch(mediaUrl);
        if (!segRes.ok) throw new Error(`Failed to fetch media chunk: ${segRes.status}`);

        const segBuffer = Buffer.from(await segRes.arrayBuffer());
        const foundPsshs = extractPsshFromBuffer(segBuffer);

        if (foundPsshs.length > 0) {
          realPssh = foundPsshs[0];
        }
      }

      // 4. Inject the real PSSH and absolute BaseURL into the MPD XML
      if (realPssh) {
        // 4a. Add the cenc namespace to the root MPD tag if missing (strict parsers need this)
        if (!mpdText.includes('xmlns:cenc')) {
          mpdText = mpdText.replace(/<MPD/i, '<MPD xmlns:cenc="urn:mpeg:cenc:2013"');
        }

        // 4b. Find any existing fake XML pssh tags and wipe them out completely
        mpdText = mpdText.replace(/<cenc:pssh[^>]*>.*?<\/cenc:pssh>/g, '');

        // 4c. Inject the real PSSH into EVERY Widevine ContentProtection tag (Audio & Video)
        const wvRegex = /<ContentProtection[^>]*schemeIdUri="urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"[^>]*>/ig;

        mpdText = mpdText.replace(wvRegex, (match) => {
          // Check if the original tag was self-closing (ends with />)
          if (match.endsWith('/>')) {
            const openTag = match.slice(0, -2) + '>'; // Remove /> and replace with >
            return `${openTag}\n        <cenc:pssh>${realPssh}</cenc:pssh>\n      </ContentProtection>`;
          } else {
            // It was already an open tag, so just slip it inside
            return `${match}\n        <cenc:pssh>${realPssh}</cenc:pssh>`;
          }
        });
      }
      // 5. Rewrite BaseURLs so Tivimate hits the CDN, not your localhost
      if (/<BaseURL>/i.test(mpdText)) {
        // Make existing <BaseURL> tags absolute
        mpdText = mpdText.replace(/<BaseURL>(.*?)<\/BaseURL>/ig, (match, innerPath) => {
          return `<BaseURL>${new URL(innerPath, finalUrl).toString()}</BaseURL>`;
        });
      } else {
        // If there was no BaseURL, inject one at the top
        const absoluteBase = finalUrl.substring(0, finalUrl.lastIndexOf('/') + 1);
        mpdText = mpdText.replace(/(<MPD[^>]*>)/i, `$1\n  <BaseURL>${absoluteBase}</BaseURL>`);
      }

      // 6. Serve the modified manifest
      res.setHeader('Content-Type', 'application/dash+xml');
      res.send(mpdText);

    } catch (err) {
      res.status(500).json({ error: 'Failed to process catch-up stream' });
      return;
    }
  } else {
    const manifestResponse = await askForManifest(targetUrl);

    if (!manifestResponse) {
      return res.status(503).json({ status: "error", message: "Server is offline or timed out" });
    }
    const choices = [5, 6, 8];
    let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

    if (!workingUrl) {
      workingUrl = manifestResponse.manifest;
    }
    res.redirect(307, workingUrl);
  }
});
app.get('/m3u/proxy/:channelnum', async (req, res) => {
  const channel = req.params.channelnum.replace(/\.mpd$/i, '');
  const { begin, end } = req.query;
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  let targetUrl = `https://bpcdn.dialog.lk/bpk-tv/${channel}/out/index.mpd`;

  if (begin && end) {
    const nowInSeconds = Math.floor(Date.now() / 1000);
    let finalEnd = Number(end);

    // If the requested end time is in the future,
    // cap it at current time minus 60 seconds.
    const offset = 40;
    if (finalEnd > (nowInSeconds - offset)) {
      finalEnd = nowInSeconds - offset;
    }
    targetUrl += `?begin=${begin}&end=${finalEnd}`;

    try {
      // 1. Fetch the original manifest (this will follow the redirect automatically)
      //const mpdRes = await fetch(targetUrl);
      //if (!mpdRes.ok) throw new Error(`Failed to fetch MPD: ${mpdRes.status}`);
      //let mpdText = await mpdRes.text();
      const manifestResponse = await askForManifest(targetUrl);

      if (!manifestResponse) {
        return res.status(503).json({ status: "error", message: "Server is offline or timed out" });
      }
      const choices = [5, 6, 8];
      let workingUrlnoproxy = await getValidCdnUrl(manifestResponse.manifest, choices);
      let workingUrl = `https://api.viulk.xyz/dtvv/proxy?url=${encodeURIComponent(workingUrlnoproxy)}`;
      if (!workingUrl) {
        workingUrl = manifestResponse.manifest;
      }
      const mpdRes = await fetch(workingUrl);
      if (!mpdRes.ok) throw new Error(`Failed to fetch MPD: ${mpdRes.status}`);
      let mpdText = await mpdRes.text();
      // The magic variable: This contains the FINAL url (e.g., bpcdncs1.dialog.lk)
      const finalUrl = mpdRes.url;

      // 1.5 Parse the MPD's BaseURL so our server knows exactly where the chunks live
      let currentBaseUrl = finalUrl.substring(0, finalUrl.lastIndexOf('/') + 1);
      const baseMatch = /<BaseURL>(.*?)<\/BaseURL>/i.exec(mpdText);
      if (baseMatch) {
        // If the MPD says "dash/", we append it to the final CDN url
        currentBaseUrl = new URL(baseMatch[1], currentBaseUrl).toString();
      }

      // 2. Parse out the first Media Segment URL
      const repIdMatch = /<Representation[^>]*id="([^"]+)"/.exec(mpdText);
      const repId = repIdMatch ? repIdMatch[1] : "";

      let mediaUrl = null;
      const asetMatches = mpdText.split('<AdaptationSet');

      for (let i = 1; i < asetMatches.length; i++) {
        const aset = asetMatches[i];
        const m = /media="([^"]+)"/.exec(aset);
        if (m) {
          let path = m[1].replace("$RepresentationID$", repId);

          // FIX: Added \s+ to ensure we strictly match the <S> tag and not <SegmentTemplate>
          const tMatch = /<S\s+[^>]*?t="(\d+)"/.exec(aset);
          const numMatch = /startNumber="(\d+)"/.exec(aset);

          if (path.includes("$Time$") && tMatch) {
            path = path.replace("$Time$", tMatch[1]);
          } else if (path.includes("$Number$")) {
            path = path.replace("$Number$", numMatch ? numMatch[1] : "1");
          }

          mediaUrl = new URL(path, currentBaseUrl).toString();
          break;
        }
      }

      let realPssh = null;
      if (mediaUrl) {
        const segRes = await fetch(mediaUrl);
        if (!segRes.ok) throw new Error(`Failed to fetch media chunk: ${segRes.status}`);

        const segBuffer = Buffer.from(await segRes.arrayBuffer());
        const foundPsshs = extractPsshFromBuffer(segBuffer);

        if (foundPsshs.length > 0) {
          realPssh = foundPsshs[0];
        }
      }

      // 4. Inject the real PSSH and absolute BaseURL into the MPD XML
      if (realPssh) {
        // 4a. Add the cenc namespace to the root MPD tag if missing (strict parsers need this)
        if (!mpdText.includes('xmlns:cenc')) {
          mpdText = mpdText.replace(/<MPD/i, '<MPD xmlns:cenc="urn:mpeg:cenc:2013"');
        }

        // 4b. Find any existing fake XML pssh tags and wipe them out completely
        mpdText = mpdText.replace(/<cenc:pssh[^>]*>.*?<\/cenc:pssh>/g, '');

        // 4c. Inject the real PSSH into EVERY Widevine ContentProtection tag (Audio & Video)
        const wvRegex = /<ContentProtection[^>]*schemeIdUri="urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"[^>]*>/ig;

        mpdText = mpdText.replace(wvRegex, (match) => {
          // Check if the original tag was self-closing (ends with />)
          if (match.endsWith('/>')) {
            const openTag = match.slice(0, -2) + '>'; // Remove /> and replace with >
            return `${openTag}\n        <cenc:pssh>${realPssh}</cenc:pssh>\n      </ContentProtection>`;
          } else {
            // It was already an open tag, so just slip it inside
            return `${match}\n        <cenc:pssh>${realPssh}</cenc:pssh>`;
          }
        });
      }
      // 5. Rewrite BaseURLs so Tivimate hits the CDN, not your localhost
      if (/<BaseURL>/i.test(mpdText)) {
        // Make existing <BaseURL> tags absolute
        mpdText = mpdText.replace(/<BaseURL>(.*?)<\/BaseURL>/ig, (match, innerPath) => {
          return `<BaseURL>${new URL(innerPath, finalUrl).toString()}</BaseURL>`;
        });
      } else {
        // If there was no BaseURL, inject one at the top
        const absoluteBase = finalUrl.substring(0, finalUrl.lastIndexOf('/') + 1);
        mpdText = mpdText.replace(/(<MPD[^>]*>)/i, `$1\n  <BaseURL>${absoluteBase}</BaseURL>`);
      }

      // 6. Serve the modified manifest
      res.setHeader('Content-Type', 'application/dash+xml');
      res.send(mpdText);

    } catch (err) {
      res.status(500).json({ error: 'Failed to process catch-up stream' });
      return;
    }
  } else {
    const manifestResponse = await askForManifest(targetUrl);

    if (!manifestResponse) {
      return res.status(503).json({ status: "error", message: "Server is offline or timed out" });
    }
    const choices = [5, 6, 8];
    let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

    if (!workingUrl) {
      workingUrl = manifestResponse.manifest;
    }
    const proxyUrl = `https://api.viulk.xyz/dtvv/proxy?url=${encodeURIComponent(workingUrl)}`;
    res.redirect(307, proxyUrl);
  }
});
app.get('/vods/movies', (req, res) => {
  const pageSize = 25;
  const page = parseInt(req.query.page) || 1; // Default to page 1

  // Calculate start and end indices
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;

  // Slice the cached array
  const paginatedVods = cachedVods.slice(startIndex, endIndex);

  res.json({
    page: page,
    pageSize: pageSize,
    totalItems: cachedVods.length,
    totalPages: Math.ceil(cachedVods.length / pageSize),
    data: paginatedVods
  });
});
app.get('/vods/shows', (req, res) => {
  const pageSize = 25;
  const page = parseInt(req.query.page) || 1; // Default to page 1

  // Calculate start and end indices
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;

  // Slice the cached array
  const paginatedVods = showVods.slice(startIndex, endIndex);

  res.json({
    page: page,
    pageSize: pageSize,
    totalItems: showVods.length,
    totalPages: Math.ceil(showVods.length / pageSize),
    data: paginatedVods
  });
});
// Simple Levenshtein helper for fuzzy matching
const getLevenshteinDistance = (a, b) => {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
    }
  }
  return matrix[a.length][b.length];
};

app.get('/search', (req, res) => {
  const query = req.query.q?.toLowerCase();
  if (!query) return res.json([]);

  let results = [];

  const getPosterUrl = (item, type) => {
    let imageId = null;
    if (type === 'show') {
      const posterObj = item.series_image_stores?.find(img => img.type === "POSTER")
        || item.series_image_stores?.[0];
      imageId = posterObj?.image_store_id;
    } else {
      imageId = item.image_store_id;
    }
    return imageId ? `https://api1.viu.lk/api/client/v1/global/images/${imageId}?accessKey=WkVjNWNscFhORDBLCg==` : null;
  };

  const processCache = (cache, type) => {
    for (const item of cache) {
      const title = item.title?.toLowerCase() || "";
      let score = 0;

      // 1. Base Relevance Scoring
      if (title === query) score = 100;
      else if (title.startsWith(query)) score = 80;
      else if (title.includes(query)) score = 50;
      else if (query.length > 2) {
        const distance = getLevenshteinDistance(query, title.substring(0, query.length + 1));
        if (distance <= 1) score = 40;
      }

      // 2. Genre Penalty Logic
      // If the genre list exists and contains 819, push it to the bottom
      const genres = item.movie_genres || item.series_genres || [];
      if (genres.includes(819)) {
        score -= 1000; // Large penalty to ensure it's at the very end
      }

      // We only push if there was a text match OR if it's a penalized item 
      // that we still want to show at the bottom.
      // If you want to HIDE them completely, use 'if (score > 0)' instead of 'if (score > -500)'
      if (score !== 0) {
        results.push({
          uid: item.uid || item.id,
          title: item.title,
          description: item.description,
          type: type,
          poster_image: getPosterUrl(item, type),
          score: score
        });
      }
    }
  };

  processCache(cachedVods, 'movie');
  processCache(showVods, 'show');

  // Sort: Highest score (most relevant) to lowest score (penalized)
  results.sort((a, b) => b.score - a.score);

  // Final clean up
  res.json(results.map(({ score, ...rest }) => rest));
});
app.get('/vods/shows/:uid', (req, res) => {
  const uid = req.params.uid;
  const vod = showVods.find(v => v.uid === uid);
  if (!vod) {
    return res.status(404).json({ status: "error", message: "VOD not found" });
  }
  res.json({ status: "ok", data: vod });
});
//find vod data by uid
app.get('/vods/movies/:uid', (req, res) => {
  const uid = req.params.uid;
  const vod = cachedVods.find(v => v.uid === uid);
  if (!vod) {
    return res.status(404).json({ status: "error", message: "VOD not found" });
  }
  res.json({ status: "ok", data: vod });
});

app.get('/dtvv/proxy', async (req, res) => {
  const targetUrl = req.query.url;

  if (!targetUrl) {
    return res.status(400).json({ error: 'Missing "url" query parameter' });
  }

  const isAllowedDomain = /^https:\/\/bpcdncs\d+\.dialog\.lk\//.test(targetUrl);
  if (!isAllowedDomain) {
    return res.status(403).json({ error: 'Forbidden: URL domain not allowed' });
  }

  try {
    const upstreamResponse = await fetch(targetUrl);

    if (!upstreamResponse.ok) {
      return res.status(upstreamResponse.status).json({
        error: `Upstream server responded with status ${upstreamResponse.status}`
      });
    }

    const contentType = upstreamResponse.headers.get('content-type');
    if (contentType) {
      res.setHeader('Content-Type', contentType);
    }

    // 1. Get the raw text of the manifest
    let data = await upstreamResponse.text();

    // 2. Calculate the absolute base path of the target URL
    // Example: Turns "https://bpcdncs4.../GlobalManifest.mpd?bkm-query" 
    // into "https://bpcdncs4.../"
    const urlObj = new URL(targetUrl);
    const pathParts = urlObj.pathname.split('/');
    pathParts.pop();
    const absoluteBasePath = `${urlObj.origin}${pathParts.join('/')}/`;

    // 3. NEW: Rewrite <BaseURL> to point to your new segment proxy route
    // Example output: <BaseURL>/dtvv/proxy-segment/https://bpcdncs4.dialog.lk/.../dash/</BaseURL>
    const proxyBasePath = `/dtvv/proxy-segment/${absoluteBasePath}`;
    data = data.replace(/<BaseURL>(.*?)<\/BaseURL>/g, `<BaseURL>${proxyBasePath}$1</BaseURL>`);

    // 4. Send the modified manifest back to the player
    res.send(data);

  } catch (error) {
    console.error('Proxy Fetch Error:', error);
    res.status(500).json({ error: 'Internal server error while fetching manifest' });
  }
});
// Use a RegExp instead of a string to bypass the strict path parser
app.get(/^\/dtvv\/proxy-segment\/(.+)/, async (req, res) => {
  // 1. Grab the target URL from the regex capture group
  let targetUrl = req.params[0];

  // Express sometimes collapses "https://" into "https:/". This safely fixes it.
  if (targetUrl.startsWith('https:/') && !targetUrl.startsWith('https://')) {
    targetUrl = targetUrl.replace('https:/', 'https://');
  }

  if (!targetUrl) {
    return res.status(400).json({ error: 'Missing target URL' });
  }

  // 2. Validate domain (same security check as before)
  const isAllowedDomain = /^https:\/\/bpcdncs\d+\.dialog\.lk\//.test(targetUrl);
  if (!isAllowedDomain) {
    return res.status(403).json({ error: 'Forbidden: URL domain not allowed' });
  }

  try {
    // 3. Fetch the binary segment from the CDN
    const upstreamResponse = await fetch(targetUrl);

    if (!upstreamResponse.ok) {
      return res.status(upstreamResponse.status).send(`Upstream error: ${upstreamResponse.status}`);
    }

    // Forward the content type (e.g., video/mp4 or audio/mp4)
    const contentType = upstreamResponse.headers.get('content-type');
    if (contentType) {
      res.setHeader('Content-Type', contentType);
    }

    // 4. CRITICAL: Read as ArrayBuffer for binary media, NOT text!
    const arrayBuffer = await upstreamResponse.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // 5. Send the binary buffer back to the video player
    res.send(buffer);

  } catch (error) {
    console.error('Segment Proxy Fetch Error:', error);
    res.status(500).send('Internal server error while fetching segment');
  }
});
app.set('trust proxy', true);
app.get('/ip', async (req, res) => {
  const userIp = req.ip;

    // 3. Grab the country from Cloudflare's specific header
    // It returns a 2-letter country code (e.g., 'US', 'GB', 'LK')
    const userCountry = req.headers['cf-ipcountry'] || 'LK';

    // 4. Send the response
    res.json({
        success: true,
        ip: userIp,
        country: userCountry,
        proxy: "Cloudflare"
    });
});
// Updated Routes
app.post('/api/client/v1/global/logout', async (req, res) => {
  const data = await getReason();
  res.status(500).json(data);
});

app.post('/api/client/v1/default/users/:userid/profiles', async (req, res) => {
  const data = await getReason();
  res.status(500).json(data);
});

app.delete('/api/client/v1/default/users/:userid/devices/:device', async (req, res) => {
  const data = await getReason();
  res.status(500).json(data);
});

app.delete('/api/client/v1/default/users/:userid/profiles/:profile', async (req, res) => {
  const data = await getReason();
  res.status(500).json(data);
});

app.put('/api/client/v1/default/users/:userid/pin/update/:type', async (req, res) => {
  const data = await getReason();
  res.status(500).json(data);
});

app.put('/api/client/v1/default/users/:userid/bookmarks/:type/:id/last_position', mockMiddleware, (req, res) => {
  res.json({ "status": "ok", "data": { "updated": true } });
});

app.get('/api/client/v1/default/users/:userid/bookmarks/:dd/:id/:type/:ids', (req, res) => {
  res.json({ "status": "ok", "data": [{ "created_at": "2025-12-13T08:43:29.000Z", "epg_recording_id": 1, "id": 1, "name": "last_position", "operator_id": 1, "profile_id": 914612, "subscriber_id": 1, "time": 5616500, "updated_at": "2024-09-13T10:51:13.262Z" }] });
});

const redirectHandler = (req, res) => {
  const baseUrl = TARGET_API_URL.replace(/\/$/, '');
  const path = req.originalUrl.replace(/^\/api/, '');

  const redirectUrl = `${baseUrl}${path}`;
  res.redirect(307, redirectUrl);
};

proxyRoutes.forEach(route => {
  app[route.method](route.url, (req, res) => {
    const baseUrl = TARGET_API_URL.replace(/\/$/, '');
    // This preserves the ACTUAL ID sent in the request (e.g., 912988)
    // because req.originalUrl contains the raw path.
    const path = req.originalUrl.replace(/^\/api/, '');

    const redirectUrl = `${baseUrl}${path}`;
    res.redirect(307, redirectUrl);
  });
});

app.get('/api/client/v1/default/users/:userid/vod/:type/:movieName', async (req, res) => {
  const { type, movieName } = req.params;
  const voddata = await askForVODwithname(movieName, type);
  vodViews[movieName] = (vodViews[movieName] || 0) + 1;
  if (!voddata) return res.status(500).json({ status: "error" });

  let movietargetUrl = `null`;
  let movielicense;

  if (voddata.data.vod_type == "INTERNAL") {
    movietargetUrl = `https://bpcdn.dialog.lk/bpk-vod/vodprod/output/${voddata.data.cm_movie || voddata.data.cm_episode}/${voddata.data.cm_movie || voddata.data.cm_episode}/index.mpd`;
    const manifestResponse = await askForManifest(movietargetUrl);
    const choices = [5, 6, 8];
    let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

    // 5. Safety Check: Did any CDN node actually work?
    if (!workingUrl) {
      workingUrl = manifestResponse.manifest;
    }

    movietargetUrl = workingUrl;
    movielicense = `${MY_PROXY_URL}/api/license`;
  } else if (voddata.data.vod_type == "LIONSGATE") {
    if (voddata.data.external_provider_data) {
      const ext = voddata.data.external_provider_data;
      const stream = ext.streams?.find(s => s.drmSchema === "widevine" && s.format === "MPEG-DASH" && s.isTrailer === false && s.streamingUrl);
      movietargetUrl = stream ? stream.streamingUrl : voddata.data.url_ott;
    } else {
      movietargetUrl = voddata.data.url_ott;
    }
    movielicense = `${MY_PROXY_URL}/api/license?lionsgate`;
  }

  res.json({
    "status": "ok",
    "data": {
      "drm": { "widevine": true, "verimatrix": false, "fairplay": false },
      "wv_license_proxy_url": movielicense,
      "url": movietargetUrl,
      "subtitles": [],
      "thumbnails": null,
      "limit_token": "3,...",
      "isDeeplink": null,
      "vod_type": "INTERNAL",
      "views": `${vodViews[movieName]} view${vodViews[movieName] !== 1 ? 's' : ''}`
    }
  });
});

app.get('/api/client/v1/default/users/:userid/live/channels/:channel', async (req, res) => {
  const channelName = req.params.channel;
  channelViews[channelName] = (channelViews[channelName] || 0) + 1;
  if (channelName == "themoviechnl") {
    return res.json({
      "status": "ok",
      "data": {
        "drm": { "widevine": false, "verimatrix": false, "fairplay": false },
        "wv_license_proxy_url": null,
        "url": "https://own.viulk.xyz/iptv/channel/1.ts",
        "limit_token": "3,...",
        "isDeeplink": null,
        "vod_type": "INTERNAL",
        "cdn_used": "broadpeakv1",
        "type": "IPTV",
        "channel_uid": channelName,
        "views": `${channelViews[channelName]} view${channelViews[channelName] !== 1 ? 's' : ''}`
      }
    });
  }
  else if (channelName == "theshowchnl") {
    return res.json({
      "status": "ok",
      "data": {
        "drm": { "widevine": false, "verimatrix": false, "fairplay": false },
        "wv_license_proxy_url": null,
        "url": "https://own.viulk.xyz/iptv/channel/2.ts",
        "limit_token": "3,...",
        "isDeeplink": null,
        "vod_type": "INTERNAL",
        "cdn_used": "broadpeakv1",
        "type": "IPTV",
        "channel_uid": channelName,
        "views": `${channelViews[channelName]} view${channelViews[channelName] !== 1 ? 's' : ''}`
      }
    });
  }
  const channelnum = channelMap[channelName];


  if (!channelnum) return res.status(404).json({ error: 'Channel not found' });

  const manifestResponse = await askForManifest(`https://bpcdn.dialog.lk/bpk-tv/${channelnum}/out/index.mpd`);

  // 4. Safety Check: Did the home server actually reply?
  if (!manifestResponse || !manifestResponse.manifest) {
    return res.status(503).json({ status: "error", message: "Home Server is offline or timed out" });
  }

  // Define choices and find the first working one
  const choices = [5, 6, 8];
  let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

  // 5. Safety Check: Did any CDN node actually work?
  if (!workingUrl) {
    workingUrl = manifestResponse.manifest;
  }

  // Success response
  res.json({
    "status": "ok",
    "data": {
      "drm": { "widevine": true, "verimatrix": false, "fairplay": false },
      "wv_license_proxy_url": `${MY_PROXY_URL}/api/license`,
      "url": workingUrl, // <-- Send the verified URL
      "limit_token": "3,...",
      "isDeeplink": null,
      "vod_type": "INTERNAL",
      "cdn_used": "broadpeakv1",
      "type": "IPTV",
      "channel_uid": channelName,
      "views": `${channelViews[channelName]} view${channelViews[channelName] !== 1 ? 's' : ''}`
    }
  });
});
/*
app.get('/api/client/v1/default/users/:userid/:eventmo/channels/:channel/shows/:showid', async (req, res) => {
    try {
        const { eventmo, channel, showid } = req.params;
        const channelName = channel;
        const channelnum = channelMap[channelName];
        if (!channelnum) return res.status(404).json({ error: 'Channel not found' });
        const responseBody = await askForRewind(eventmo, channelnum, showid);
        if (responseBody?.data?.data) {
            responseBody.data.data.wv_license_proxy_url = `${MY_PROXY_URL}/api/license`;
        }
        res.json(responseBody.data);
    } catch (err) {
        res.status(500).json({ error: "Internal Proxy Error" });
    }
});*/

app.get('/api/client/v1/default/users/:userid/:eventmo/channels/:channel/shows/:showid', async (req, res) => {
  try {
    const { eventmo, channel, showid } = req.params;
    const channelName = channel;
    const channelnum = channelMap[channelName];
    channelViews[channelName] = (channelViews[channelName] || 0) + 1;
    const show = cachedPrograms.find(p => p.id === Number(showid));

    if (!show) return res.status(404).json({ error: 'Show not found' });
    const formatTime = (isoString) => {
      return isoString.replace(/[-:]/g, "").split(".")[0];
    };
    const convertedbegin = formatTime(show.start);
    const convertedend = formatTime(show.end);
    const originalUrl = `https://bpcdn.dialog.lk/bpk-tv/${channelnum}/out/index.mpd?begin=${convertedbegin}&end=${convertedend}`;
    const manifestResponse = await askForManifest(originalUrl);
    if (!manifestResponse) {
      return res.status(503).json({ status: "error", message: "Home Server is offline or timed out" });
    }
    if (!manifestResponse) {
      return res.status(503).json({ status: "error", message: "Home Server is offline or timed out" });
    }
    const choices = [5, 6, 8];
    let workingUrl = await getValidCdnUrl(manifestResponse.manifest, choices);

    // 5. Safety Check: Did any CDN node actually work?
    if (!workingUrl) {
      workingUrl = manifestResponse.manifest;
    }

    res.json({
      "status": "ok",
      "data": {
        "drm": { "widevine": true, "verimatrix": false, "fairplay": false },
        "wv_license_proxy_url": `${MY_PROXY_URL}/api/license`,
        "url": workingUrl,
        "limit_token": "3,...",
        "isDeeplink": null,
        "vod_type": "INTERNAL",
        "title": show.title,
        "cdn_used": "broadpeakv1",
        "type": "IPTV",
        "channel_uid": channelName,
        "views": `${channelViews[channelName]} view${channelViews[channelName] !== 1 ? 's' : ''}`
      }
    });
  } catch (err) {
    res.status(500).json({ error: "Internal Proxy Error" });
  }
});
app.post('/api/client/v2/global/login', proxy(TARGET_API_URL, {
  // 1. Ensure the path matches exactly on the target
  proxyReqPathResolver: function (req) {
    return '/api/client/v2/global/login';
  },

  // 2. Modify the body before sending
  proxyReqBodyDecorator: function (bodyContent, srcReq) {
    console.log('⚡ INTERCEPTING /login: Spoofing device to MOBILE/ANDROID...');

    try {
      // If body-parser is running, bodyContent might already be an Object.
      // If not, it might be a Buffer or String. We handle both cases:
      let body = bodyContent;

      if (Buffer.isBuffer(body)) {
        body = body.toString('utf8');
      }

      // Parse if it's a string
      if (typeof body === 'string') {
        body = JSON.parse(body);
      }
      console.log(JSON.stringify(body))
      // 3. Edit the fields
      body.device_class = "MOBILE";
      body.device_type = "MOBILE";
      body.device_os = "ANDROID";
      body.login_type = "Mac";

      // 4. Return the new body as a JSON string
      console.log(JSON.stringify(body))
      return JSON.stringify(body);

    } catch (e) {
      console.error('❌ Failed to spoof login body:', e);
      return bodyContent; // Send original if something breaks
    }
  }
}));

// ==========================================
// 🔐 HYBRID LICENSE PROXY (Best of Both Worlds)
// ==========================================
app.post('/api/license', async (req, res) => {
  try {
    // 1. Manually buffer the request body
    // This fixes the "undefined reading length" error on Web
    const chunks = [];
    for await (const chunk of req) {
      chunks.push(chunk);
    }
    const bodyBuffer = Buffer.concat(chunks);
    const drmtype = req.query.fairplay !== undefined ? "fp" : "wv"
    // 2. Prepare the Upstream Request
    const mode = req.query.lionsgate !== undefined ? "lionsgate" : "bp";
    let licenseUrl = await askForLicense();

    if (!licenseUrl) {
      return res.status(500).send("Could not retrieve License URL");
    }

    licenseUrl = licenseUrl.replace("/bp/", `/${mode}/`);
    licenseUrl = licenseUrl.replace("/wv/", `/${drmtype}/`);
    const options = new URL(licenseUrl);

    // 3. Send to License Server
    const proxyReq = https.request({
      method: "POST",
      hostname: options.hostname,
      path: options.pathname + options.search,
      headers: {
        // Forward critical headers from the client
        "user-agent": req.headers["user-agent"],
        "content-type": req.headers["content-type"] || "application/octet-stream",
        "content-length": bodyBuffer.length,

        // Ensure the Host is set to the LICENSE SERVER, not your proxy
        "host": options.hostname
      },
      agent: proxyAgent
    }, proxyRes => {
      res.status(proxyRes.statusCode);
      Object.entries(proxyRes.headers).forEach(([k, v]) => res.setHeader(k, v));
      proxyRes.pipe(res);
    });

    proxyReq.on("error", err => {
      console.error("License proxy error:", err);
      if (!res.headersSent) res.status(500).send("License proxy failed.");
    });

    // 4. Write the clean buffer we captured in step 1
    proxyReq.write(bodyBuffer);
    proxyReq.end();

  } catch (e) {
    console.error("Critical Error in /api/license:", e);
    if (!res.headersSent) res.status(500).send("Server Error");
  }
});
// ==========================================
// 🚀 OPTIMIZATION: IMAGE REDIRECT
// ==========================================
// This sits BEFORE the proxy so images are 302 redirected immediately.
app.get('/api/client/v1/global/images/:imageId', (req, res) => {
  const baseUrl = TARGET_API_URL.replace(/\/$/, '');
  let cleanPath = req.originalUrl;
  if (cleanPath.startsWith('/api/api/')) {
    cleanPath = cleanPath.replace('/api/api/', '/api/');
  }
  if (!cleanPath.startsWith('/')) cleanPath = '/' + cleanPath;
  const redirectUrl = `${baseUrl}${cleanPath}`;
  res.redirect(302, redirectUrl);
});

app.get('/api/client/v1/global/content_device_concurrency/:whatever', (req, res) => res.status(202).send());

// ==========================================
// 📝 CHANNELS ROUTE
// ==========================================
app.get('/api/client/v2/default/users/:userid/channels', async (req, res) => {
  console.log('⚡unlocking channels.');
  const rawChannels = [{ "id": 11, "position": 1, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 324, 699, 871], "order": 0 }, { "id": 12, "position": 2, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 12, 324, 871], "order": 1 }, { "id": 13, "position": 3, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 3, 12, 324, 699], "order": 2 }, { "id": 14, "position": 4, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 324, 699, 871], "order": 3 }, { "id": 15, "position": 5, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 871, 699, 324], "order": 4 }, { "id": 16, "position": 6, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 699, 871, 3, 324], "order": 5 }, { "id": 3, "position": 7, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 12, 3], "order": 6 }, { "id": 5, "position": 8, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 12, 3], "order": 7 }, { "id": 6, "position": 9, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 12, 3], "order": 8 }, { "id": 7, "position": 10, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 324, 12, 3, 871], "order": 9 }, { "id": 17, "position": 11, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12, 3, 699, 871], "order": 10 }, { "id": 26, "position": 12, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 3, 12, 324], "order": 11 }, { "id": 19, "position": 13, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 871, 699, 324, 3], "order": 12 }, { "id": 20, "position": 14, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 324, 12, 3, 699], "order": 13 }, { "id": 21, "position": 15, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324, 12], "order": 14 }, { "id": 22, "position": 16, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 12, 3, 871, 324], "order": 15 }, { "id": 23, "position": 17, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 699, 871, 3, 324], "order": 16 }, { "id": 24, "position": 18, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 3, 12, 324], "order": 17 }, { "id": 25, "position": 19, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 699, 871, 324, 3], "order": 18 }, { "id": 18, "position": 20, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 3], "order": 19 }, { "id": 27, "position": 21, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 12, 3], "order": 20 }, { "id": 28, "position": 22, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 324, 12, 3, 699], "order": 21 }, { "id": 29, "position": 23, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324, 12], "order": 22 }, { "id": 30, "position": 24, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 871, 699, 324], "order": 23 }, { "id": 31, "position": 25, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12, 699, 871, 3], "order": 24 }, { "id": 32, "position": 26, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 3, 324, 699, 871], "order": 25 }, { "id": 33, "position": 27, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 12, 699, 871], "order": 26 }, { "id": 34, "position": 28, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 324, 699, 871], "order": 27 }, { "id": 35, "position": 29, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 12, 3], "order": 28 }, { "id": 36, "position": 30, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324, 3, 871, 699], "order": 29 }, { "id": 37, "position": 31, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 12, 324, 871], "order": 30 }, { "id": 38, "position": 32, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 3, 12], "order": 31 }, { "id": 39, "position": 33, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 324, 12, 3, 871], "order": 32 }, { "id": 40, "position": 34, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324], "order": 33 }, { "id": 41, "position": 35, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 699, 871, 12], "order": 34 }, { "id": 42, "position": 36, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 12, 3, 871], "order": 35 }, { "id": 43, "position": 37, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 12, 3], "order": 36 }, { "id": 44, "position": 38, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324], "order": 37 }, { "id": 45, "position": 39, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324], "order": 38 }, { "id": 46, "position": 40, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 12, 699, 871], "order": 39 }, { "id": 47, "position": 41, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 871, 699, 3, 324], "order": 40 }, { "id": 48, "position": 42, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 324, 699, 871], "order": 41 }, { "id": 49, "position": 43, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871], "order": 42 }, { "id": 50, "position": 44, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 3, 699, 324, 12], "order": 43 }, { "id": 51, "position": 45, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 12, 324, 871, 699], "order": 44 }, { "id": 52, "position": 46, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 3], "order": 45 }, { "id": 53, "position": 47, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12], "order": 46 }, { "id": 54, "position": 48, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12, 3, 871, 699], "order": 47 }, { "id": 55, "position": 49, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 871, 324, 12], "order": 48 }, { "id": 56, "position": 50, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 49 }, { "id": 57, "position": 51, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324], "order": 50 }, { "id": 58, "position": 52, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 3], "order": 51 }, { "id": 68, "position": 53, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 871, 699, 324, 3], "order": 52 }, { "id": 2086, "position": 54, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 324, 3, 871], "order": 53 }, { "id": 61, "position": 55, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 3, 324], "order": 54 }, { "id": 62, "position": 56, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 12], "order": 55 }, { "id": 63, "position": 57, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324, 3], "order": 56 }, { "id": 64, "position": 58, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324, 3], "order": 57 }, { "id": 2, "position": 59, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 871, 12, 324], "order": 58 }, { "id": 60, "position": 60, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 3, 699, 871, 324], "order": 59 }, { "id": 67, "position": 61, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324, 12], "order": 60 }, { "id": 2126, "position": 62, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 871, 324], "order": 61 }, { "id": 70, "position": 63, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 3, 324], "order": 62 }, { "id": 71, "position": 64, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324, 871, 699, 3], "order": 63 }, { "id": 72, "position": 65, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 3], "order": 64 }, { "id": 73, "position": 66, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324, 12], "order": 65 }, { "id": 74, "position": 67, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 12], "order": 66 }, { "id": 75, "position": 68, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 67 }, { "id": 76, "position": 69, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 68 }, { "id": 77, "position": 70, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 69 }, { "id": 78, "position": 71, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 70 }, { "id": 79, "position": 72, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 3, 12], "order": 71 }, { "id": 80, "position": 73, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 3, 12, 324, 699], "order": 72 }, { "id": 81, "position": 74, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 871], "order": 73 }, { "id": 82, "position": 75, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12, 3, 699, 871], "order": 74 }, { "id": 83, "position": 76, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 699, 871, 12], "order": 75 }, { "id": 84, "position": 77, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 12, 3], "order": 76 }, { "id": 85, "position": 78, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 871, 12, 3], "order": 77 }, { "id": 86, "position": 79, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699, 3], "order": 78 }, { "id": 87, "position": 80, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 3], "order": 79 }, { "id": 88, "position": 81, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 12, 324, 3], "order": 80 }, { "id": 89, "position": 82, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324], "order": 81 }, { "id": 90, "position": 83, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 12, 324, 871], "order": 82 }, { "id": 91, "position": 84, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 324, 3], "order": 83 }, { "id": 92, "position": 85, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 324, 12], "order": 84 }, { "id": 93, "position": 86, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699], "order": 85 }, { "id": 94, "position": 87, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 324, 3], "order": 86 }, { "id": 95, "position": 88, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 3, 324, 12], "order": 87 }, { "id": 96, "position": 89, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 12, 324, 871], "order": 88 }, { "id": 97, "position": 90, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 3, 871], "order": 89 }, { "id": 98, "position": 91, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [12, 324, 871, 699], "order": 90 }, { "id": 99, "position": 92, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 324, 12, 3, 871], "order": 91 }, { "id": 100, "position": 93, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 324, 699], "order": 92 }, { "id": 101, "position": 94, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 324], "order": 93 }, { "id": 102, "position": 95, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871], "order": 94 }, { "id": 103, "position": 96, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 12, 324, 871], "order": 95 }, { "id": 104, "position": 97, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 324, 12, 3], "order": 96 }, { "id": 105, "position": 98, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 699, 871], "order": 97 }, { "id": 106, "position": 99, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 3], "order": 98 }, { "id": 107, "position": 100, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 324], "order": 99 }, { "id": 108, "position": 101, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871], "order": 100 }, { "id": 109, "position": 102, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 699, 324, 871], "order": 101 }, { "id": 110, "position": 103, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 871, 699], "order": 102 }, { "id": 111, "position": 104, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 3, 324, 871], "order": 103 }, { "id": 112, "position": 105, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 871, 699], "order": 104 }, { "id": 113, "position": 106, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871, 324, 3], "order": 105 }, { "id": 69, "position": 107, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 106 }, { "id": 59, "position": 108, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 12], "order": 107 }, { "id": 8, "position": 109, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 108 }, { "id": 116, "position": 110, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 109 }, { "id": 117, "position": 111, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3, 871, 699], "order": 110 }, { "id": 118, "position": 112, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 699, 871, 324], "order": 111 }, { "id": 119, "position": 113, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 324, 3], "order": 112 }, { "id": 120, "position": 114, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 113 }, { "id": 121, "position": 115, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 114 }, { "id": 122, "position": 116, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 699, 871], "order": 115 }, { "id": 123, "position": 117, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 116 }, { "id": 124, "position": 118, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 117 }, { "id": 125, "position": 119, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 118 }, { "id": 126, "position": 120, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 119 }, { "id": 127, "position": 121, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 120 }, { "id": 128, "position": 122, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 3], "order": 121 }, { "id": 129, "position": 123, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 871, 699, 324], "order": 122 }, { "id": 130, "position": 124, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324, 699, 871], "order": 123 }, { "id": 131, "position": 125, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [3, 324], "order": 124 }, { "id": 132, "position": 126, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": true, "ts_duration": 72, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699, 3, 324], "order": 125 }, { "id": 133, "position": 127, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 871, 699], "order": 126 }, { "id": 2085, "position": 128, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871], "order": 127 }, { "id": 1831, "position": 131, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 871], "order": 128 }, { "id": 1833, "position": 133, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 871], "order": 129 }, { "id": 1834, "position": 134, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [699, 324, 871], "order": 130 }, { "id": 1835, "position": 135, "parental_hidden": false, "hidden": false, "purchased": "2035-06-01T00:00:00.000Z", "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [324, 699, 871], "order": 131 }, { "id": 1836, "position": 136, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699], "order": 132 }, { "id": 1837, "position": 137, "parental_hidden": false, "hidden": false, "purchased": null, "timeshiftable": false, "ts_duration": 0, "recordable": false, "rec_quota": 0, "favorited": false, "packages": [871, 699], "order": 133 }];
  const unlockedChannels = rawChannels.map(channel => {
    return {
      ...channel, // Keeps all the original info (ID, name, etc.)
      packages: [3, 12, 324, 699, 871] // Overwrites the packages for everyone
    };
  });
  res.json({
    "status": "ok",
    "data": unlockedChannels
  });
});

// ==========================================
// 🚀 OPTIMIZATION 4: SMART CACHE LOGIC
// ==========================================
const onlyCacheSafeRoutes = (req, res) => {
  // Only cache GET requests
  if (req.method !== 'GET') return false;

  // ❌ NEVER CACHE:
  if (req.url.includes('/login')) return false;
  if (req.url.includes('/license')) return false;
  if (req.url.includes('/subscribe')) return false;
  if (req.url.includes('/refresh')) return false;

  // ❌ Don't cache binary files (images/video) - we redirect those anyway
  if (req.url.match(/\.(ts|mp4|m3u8|mpd|jpg|png)$/)) return false;

  // ✅ CACHE EVERYTHING ELSE (Channels, EPG, Movies)
  return true;
};

// ==========================================
// 5. MAIN PROXY (Optimized + Cached)
// ==========================================
const REGEX_API_URL = new RegExp("https://api.viu.lk", "g");
const REGEX_CDN_URL = new RegExp("https://bpcdn.dialog.lk", "g");
const REPLACEMENT_CDN = "https://bpc.viulk.xyz/api2";



// Apply Cache Middleware BEFORE the Proxy
app.use('/', cache('10 minutes', onlyCacheSafeRoutes), proxy(TARGET_API_URL, {
  https: true,
  agent: proxyAgent,
  parseReqBody: false,

  proxyReqOptDecorator: function (proxyReqOpts) {
    if (proxyReqOpts.headers['accept-encoding']) delete proxyReqOpts.headers['accept-encoding'];
    return proxyReqOpts;
  },

  userResHeaderDecorator(headers, userReq) {
    headers['access-control-allow-origin'] = userReq.headers.origin || '*';
    return headers;
  },

  userResDecorator: function (proxyRes, proxyResData, userReq) {
    const path = userReq.path;
    const contentType = (proxyRes.headers['content-type'] || '').toLowerCase();

    // 1. BINARY PASS-THROUGH
    if (
      contentType.includes('image') || contentType.includes('video') ||
      contentType.includes('audio') || contentType.includes('font') ||
      contentType.includes('octet-stream') || path.match(/\.(ts|mp4|m3u8|mpd)$/)
    ) {
      return proxyResData;
    }

    // 2. TEXT PROCESSING
    let dataStr = proxyResData.toString('utf8');

    dataStr = dataStr.replace(REGEX_API_URL, MY_PROXY_URL);
    dataStr = dataStr.replace(REGEX_CDN_URL, REPLACEMENT_CDN);

    // 3. SMART MODIFICATION
    const modificationRule = RES_BODY_MODIFICATIONS.find(rule => {
      return (rule.pattern instanceof RegExp) ? rule.pattern.test(path) : rule.pattern === path;
    });

    if (!modificationRule) {
      return dataStr;
    }

    try {
      let dataJSON = JSON.parse(dataStr);
      dataJSON = modificationRule.modifier(dataJSON);
      return JSON.stringify(dataJSON);
    } catch (e) {
      return dataStr;
    }
  }
}));
/**
 * Tests multiple CDN nodes in parallel and returns the first valid URL.
 *
 * @param {string} originalUrl - The base URL to modify.
 * @param {number[]} choices - Array of node numbers to test.
 * @returns {Promise<string|null>} - The first working URL, or null if all fail.
 */
async function getValidCdnUrl(originalUrl, choices) {
  // Create an array of validation promises
  const checkPromises = choices.map(async (node) => {
    const testUrl = originalUrl.replace(/bpcdncs\d\.dialog\.lk/, `bpcdncs${node}.dialog.lk`);

    // Add a timeout (e.g., 3 seconds) so dead nodes don't hang the request
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    try {
      // A HEAD request is faster than GET since it only fetches headers.
      // Note: If the CDN blocks HEAD requests, change this to 'GET'.
      const response = await fetch(testUrl, {
        method: 'HEAD',
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      // If the server returns a 200-299 status code, it's valid
      if (response.ok) {
        return testUrl;
      }
      throw new Error(`Node ${node} returned HTTP ${response.status}`);
    } catch (error) {
      clearTimeout(timeoutId);
      throw error; // Let Promise.any catch this rejection
    }
  });

  try {
    // Promise.any returns the FIRST promise that resolves successfully.
    return await Promise.any(checkPromises);
  } catch (aggregateError) {
    // If ALL promises reject (all nodes are down), return null
    return null;
  }
}
// ==========================================
// 🔌 SOCKET HELPERS
// ==========================================
async function askForManifest(videoLink) {
  if (!homeServerSocket) {
    console.error("❌ Error: Home Server is not connected yet.");
    return;
  }

  console.log(`Dedi: Asking Home Server for ${videoLink}...`);

  try {
    const response = await homeServerSocket.timeout(10000).emitWithAck("get_stream_data", { url: videoLink });
    return response;
  } catch (e) {
    console.error("⚠️ Error: Home server timed out or failed.");
  }
}

async function askForLicense() {
  const now = Date.now();

  // 1. Return the cached license if it exists and is less than 6 hours old
  if (cachedLicenseUrl && (now - lastLicenseFetchTime < CACHE_DURATION_MS)) {
    return cachedLicenseUrl;
  }

  // 2. If no valid cache, we need to fetch. Check if socket is available.
  if (!homeServerSocket) {
    console.error("No homeServerSocket available. Falling back to cache if it exists.");
    return cachedLicenseUrl;
  }

  try {
    // 3. Request a fresh license
    const response = await homeServerSocket.timeout(10000).emitWithAck("get_license", { url: null });

    // 4. Update the cache if the response is valid
    if (response && response.license) {
      cachedLicenseUrl = response.license;
      lastLicenseFetchTime = Date.now();
      return cachedLicenseUrl;
    }
  } catch (e) {
    console.error("Home server timeout or error:", e.message);
  }

  // 5. Fallback: If the fetch failed (timeout/error), return the stale cached URL 
  // instead of breaking the video stream, or null if it never cached.
  return cachedLicenseUrl;
}
async function askForVODwithname(name, type) {
  if (!homeServerSocket) return null;
  try {
    return await homeServerSocket.timeout(10000).emitWithAck("get_vod_data", { name, type });
  } catch (e) { console.error("Home server timeout"); }
}
async function askForRewind(eventmo, channel, showid) {
  if (!homeServerSocket) return null;
  try {
    return await homeServerSocket.timeout(10000).emitWithAck("get_rewind", { eventmo, channel, showid });
  } catch (e) { console.error("Home server timeout"); }
}

http.createServer(app).listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 OPTIMIZED HTTP Proxy running at ${MY_PROXY_URL}`);
});
