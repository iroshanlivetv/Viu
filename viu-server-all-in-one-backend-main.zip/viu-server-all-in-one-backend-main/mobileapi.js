const express = require('express');
const proxy = require('express-http-proxy');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
// 🚀 NEW IMPORTS
const compression = require('compression');
const apicache = require('apicache');


// ==========================================
// ⚙️ CONFIGURATION
// ==========================================
const USE_HTTPS = false;
const PORT = 7563;
const MY_LOCAL_IP = 'mobileapi.viulk.xyz/api';
const MAIN_API = 'https://api.viulk.xyz'


const MY_PROXY_URL = `${USE_HTTPS ? `https://${MY_LOCAL_IP}:${PORT}` : `https://${MY_LOCAL_IP}`}`;
const TARGET_API_URL = 'https://api1.viu.lk';

// 🚀 OPTIMIZATION 1: Connection Pooling
const proxyAgent = new https.Agent({
    keepAlive: true,
    maxSockets: 100,
    keepAliveMsecs: 1000,
    timeout: 10000
});

const channelMap = {
    "channelone": "Ch001", "rupavahini": "Ch002", "nethratv": "Ch003", "itn": "Ch004",
    "vasanthamtv": "Ch005", "tvderana": "Ch006", "swarnavahini": "Ch007", "sirasatv": "Ch008",
    "shakthitv": "Ch009", "tv1": "Ch010", "hirutv": "Ch011", "supreme": "Ch012",
    "arttelevision": "Ch013", "adaderana24": "Ch014", "siyathatv": "Ch015", "harithatv": "Ch016",
    "tvdidula": "Ch017", "rideetv": "Ch018", "citihitz": "Ch019", "rangiri": "Ch021",
    "hitv": "Ch022", "pragna": "Ch023", "damsathara": "Ch024", "jayatv": "Ch025",
    "buddhisttv": "Ch026", "shraddhatv": "Ch027", "godtv": "Ch028", "ewtn": "Ch029",
    "aljazeera": "Ch030", "abcaustralia": "Ch031", "bbcworld": "Ch032", "CGTN": "Ch033",
    "cnn": "Ch034", "ndtv": "Ch035", "france24": "Ch036", "euronews": "Ch037",
    "bloomberg": "Ch038", "cnbc": "Ch039", "B4UMusic": "Ch040", "romantico": "Ch041",
    "channelc": "Ch042", "jayamax": "Ch043", "zingtv": "Ch044", "davinci": "Ch045",
    "cbeebies": "Ch046", "cartoonnetwork": "Ch047", "aplus": "Ch048", "nickelodeon": "Ch049",
    "babytv": "Ch050", "disneyjr": "Ch051", "nickjr": "Ch052", "moonbug": "Ch053",
    "pogo": "Ch054", "animalplanet": "Ch055", "discovery": "Ch056", "discoveryscience": "Ch057",
    "tlc": "Ch058", "natgeo": "Ch059", "ngcwild": "Ch060", "historytv18": "Ch061",
    "paparetv1": "Ch062", "paparesd": "Ch063", "sonysports1": "Ch064", "tencricket": "Ch065",
    "sonysports2": "Ch066", "eurosport": "Ch067", "starsports1": "Ch208", "starsports2": "Ch069",
    "hbosignature": "Ch070", "hbofamily": "Ch071", "andflix": "Ch072", "hitsmovies": "Ch073",
    "sonypix": "Ch074", "hits": "Ch075", "zeecafe": "Ch076", "warnertv": "Ch077",
    "axn": "Ch078", "colorsinfinity": "Ch079", "fashiontv": "Ch080", "disneyint": "Ch081",
    "comedyzone": "Ch082", "bbcearth": "Ch083", "starbharath": "Ch084", "sonyset": "Ch085",
    "setmax": "Ch086", "stargold": "Ch087", "colors": "Ch088", "starplus": "Ch089",
    "b4umovies": "Ch090", "stargoldromance": "Ch091", "zeecinema": "Ch092", "colorstamil": "Ch093",
    "jayatvind": "Ch094", "jayamovies": "Ch095", "starvijay": "Ch096", "kalaignartv": "Ch097",
    "zeetamil": "Ch098", "siripollitv": "Ch099", "jayaplus": "Ch100", "zeethirai": "Ch101",
    "nenasasinhalaal": "Ch102", "nenasasinhalagrade6to9": "Ch103", "nenasatamilal": "Ch104",
    "nenasasinhalaol": "Ch105", "nenasatamilol": "Ch106", "hgtv": "Ch107", "foodnetwork": "Ch108",
    "discoveryhdworld": "Ch109", "animalplanethd": "Ch110", "axnhd": "Ch111",
    "rockentertainmenthd": "Ch112", "hitsnow": "Ch113", "hbohd": "Ch114", "starmovieshd": "Ch115",
    "cinemaworldhd": "Ch116", "cinemaxhd": "Ch117", "hbohitshd": "Ch118",
    "starmoviesselecthd": "Ch119", "starsportshd1": "Ch120", "starsselecthd1": "Ch121",
    "starsselecthd2": "Ch122", "sonysports2hd": "Ch123", "sonysports5hd": "Ch124",
    "premiersports": "Ch125", "thepaparehd": "Ch126", "thepapare2hd": "Ch127",
    "mobeventchannel": "Ch139", "trtworld": "Ch146", "dwenglish": "Ch151", "raiitalia": "Ch148",
    "phoenixinfo": "Ch150", "tv5monde": "Ch147", "colorsrishty": "Ch152", "channel20": "Ch020",
    "discoveryturbo": "Ch213", "eventchannel2": "",
};
const proxyRoutes = [
    // --- Existing Routes ---
    { method: 'get',  url: '/api/client/v2/default/client_translations' },
{ method: 'get',  url: '/api/client/v1/default/skins' },
//{ method: 'get',  url: '/api/client/v1/default/client_configuration' },

// Icon packs (Handles "1" or any other pack ID)
{ method: 'get',  url: '/api/client/v1/default/icon_packs/:packid/ttf' },
{ method: 'get',  url: '/api/client/v1/default/icon_packs/:packid/codepoint' },

// Global Configs
{ method: 'get',  url: '/api/client/v1/global/currencies' },
{ method: 'get',  url: '/api/client/v1/global/languages' },
{ method: 'get',  url: '/api/client/v1/default/services' },

// User Specific Endpoints

//{ method: 'get',  url: '/api/client/v1/default/users/:userid/info' },
//{ method: 'get',  url: '/api/client/v1/default/users/:userid' },

];
const app = express();
let cache = apicache.middleware;

// ==========================================
// 🚀 OPTIMIZATION 3: COMPRESSION (GZIP)
// ==========================================
// Shrink all text/json responses by ~80%
app.use(compression());

// ==========================================
// 🛠️ RESPONSE MODIFIERS
// ==========================================
const RES_BODY_MODIFICATIONS = [
    {
        pattern: /\/api\/client\/v1\/default\/users\/\d+\/packages/,
        modifier: (json) => {
            if (json && Array.isArray(json.data)) {
                json.data = json.data.map(item => ({ ...item, purchased: "2035-06-01T00:00:00Z" }));
            }
            return json;
        }
    },
{
    pattern: '/api/client/v1/default/proxy_url',
    modifier: (json) => {
        if (json && json.data) json.data.url = MY_PROXY_URL;
        return json;
    }
},
{
    pattern: /^\/api\/client\/v1\/default\/users\/\d+\/movies\/\d+$/,
    modifier: (json) => {
        if (json && json.data) {
            json.data.purchased = true;
            json.data.purchased_till = "2035-06-01T00:00:00Z";
        }
        return json;
    }
},
{
    pattern: /^\/api\/client\/v1\/default\/users\/\d+\/series\/\d+$/,
    modifier: (json) => {
        if (json && json.data) {
            json.data.purchased = true;
            json.data.purchased_till = "2035-06-01T00:00:00Z";
        }
        return json;
    }
},
{
    // Only replace required_version and recommended_version
    pattern: /\/api\/client\/v1\/default\/client_configuration/,
    modifier: (json) => {
        console.log('🔄 Replacing Versions recursively (including stringified JSON)...');

        const targetVersion = "15.40.1";

        const replaceRecursive = (obj) => {
            if (Array.isArray(obj)) {
                obj.forEach(item => replaceRecursive(item));
            } else if (typeof obj === 'object' && obj !== null) {
                for (const key in obj) {
                    const val = obj[key];

                    // 1. Direct match: Check for version keys
                    if (key === 'required_version' || key === 'recommended_version') {
                        obj[key] = targetVersion;
                    }

                    // 2. Normal recursion: It's a standard object/array
                    else if (typeof val === 'object' && val !== null) {
                        replaceRecursive(val);
                    }

                    // 3. Stringified JSON: Check if string contains version keys
                    else if (typeof val === 'string' && (
                        val.includes('required_version') ||
                        val.includes('recommended_version')
                    )) {
                        try {
                            let parsed = JSON.parse(val);
                            replaceRecursive(parsed);
                            obj[key] = JSON.stringify(parsed);
                        } catch (e) {
                            // Parsing failed, ignore
                        }
                    }
                }
            }
        };

        replaceRecursive(json);
        return json;
    }
},
];

// ==========================================
// 1. MIDDLEWARE (CORS) - LIGHTWEIGHT
// ==========================================
app.use((req, res, next) => {
    const origin = req.headers.origin || '*';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
    const requestedHeaders = req.headers['access-control-request-headers'];
    res.setHeader('Access-Control-Allow-Headers', requestedHeaders || '*');
    res.setHeader('Access-Control-Allow-Credentials', 'true');

    // Quick exit for OPTIONS
    if (req.method === 'OPTIONS') return res.sendStatus(200);

    // Nginx Strip Fix
    if (req.url.startsWith('/api/')) req.url = req.url.replace('/api/', '/');
    next();
});

// 🚀 OPTIMIZATION 2: Removed Global Body Parser
// We only apply body parser to the specific routes that actually need it.
const jsonParser = bodyParser.json({ limit: '10mb' });
const urlEncodedParser = bodyParser.urlencoded({ extended: true, limit: '10mb' });
const mockMiddleware = [jsonParser, urlEncodedParser];

// ==========================================
// ⚡ MOCK ROUTES
// ==========================================

// Helper function to fetch the reason from the API
const getReason = async () => {
    try {
        const response = await fetch('https://naas.isalman.dev/no');
        return await response.json();
    } catch (error) {
        // Fallback in case the external API is down
        return { reason: "An unknown error occurred." };
    }
};

// Updated Routes
app.post('/api/client/v1/global/logout', async (req, res) => {
    const data = await getReason();
    res.status(500).json(data);
});

app.post('/api/client/v1/default/users/:userid/profiles', async (req, res) => {
    const data = await getReason();
    res.status(500).json(data);
});

app.delete('/api/client/v1/default/users/:userid/devices/:device', async (req, res) => {
    const data = await getReason();
    res.status(500).json(data);
});

app.delete('/api/client/v1/default/users/:userid/profiles/:profile', async (req, res) => {
    const data = await getReason();
    res.status(500).json(data);
});

app.put('/api/client/v1/default/users/:userid/pin/update/:type', async (req, res) => {
    const data = await getReason();
    res.status(500).json(data);
});

app.put('/api/client/v1/default/users/:userid/bookmarks/:type/:id/last_position', mockMiddleware, (req, res) => {
    res.json({"status":"ok","data":{"updated":true}});
});

app.get('/api/client/v1/default/users/:userid/bookmarks/:dd/:id/:type/:ids', (req, res) => {
    res.json({"status":"ok","data":[{"created_at":"2025-12-13T08:43:29.000Z","epg_recording_id":1,"id":1,"name":"last_position","operator_id":1,"profile_id":914612,"subscriber_id":1,"time":5616500,"updated_at":"2024-09-13T10:51:13.262Z"}]});
});
const redirectHandler = (req, res) => {
    const baseUrl = TARGET_API_URL.replace(/\/$/, '');
    const path = req.originalUrl.replace(/^\/api/, '');

    const redirectUrl = `${baseUrl}${path}`;
    res.redirect(307, redirectUrl);
};

proxyRoutes.forEach(route => {
    app[route.method](route.url, (req, res) => {
        const baseUrl = TARGET_API_URL.replace(/\/$/, '');
        // This preserves the ACTUAL ID sent in the request (e.g., 912988)
        // because req.originalUrl contains the raw path.
        const path = req.originalUrl.replace(/^\/api/, '');

        const redirectUrl = `${baseUrl}${path}`;
        res.redirect(307, redirectUrl);
    });
});

app.get('/api/client/v1/default/users/:userid/vod/:type/:movieName', (req, res) => {
    const baseUrl = MAIN_API.replace(/\/$/, '');
    const path = req.originalUrl.startsWith('/') ? req.originalUrl : '/' + req.originalUrl;

    const redirectUrl = `${baseUrl}${path}`;
    res.redirect(307, redirectUrl);
});

app.get('/api/client/v1/default/users/:userid/live/channels/:channel', async (req, res) => {
    const channelName = req.params.channel;
    const channelnum = channelMap[channelName];
    if (!channelnum) return res.status(404).json({ error: 'Channel not found' });

    res.json({
        "status":"ok",
        "data":{
            "drm":{"widevine":true,"verimatrix":false,"fairplay":false},
            "wv_license_proxy_url":`${MY_PROXY_URL}/api/license`,
            "url":`https://bpcdn.dialog.lk/bpk-tv/${channelnum}/out/index.mpd`,
            "limit_token":"3,...",
            "isDeeplink":null,
            "vod_type":"INTERNAL",
            "cdn_used":"broadpeakv1",
            "channel_uid":channelName
        }
    });
});
app.get('/api/client/v1/default/users/:userid/:eventmo/channels/:channel/shows/:showid', (req, res) => {
    const baseUrl = MAIN_API.replace(/\/$/, '');
    const path = req.originalUrl.startsWith('/') ? req.originalUrl : '/' + req.originalUrl;

    const redirectUrl = `${baseUrl}${path}`;
    // 302 = Temporary Redirect (Don't cache the redirect itself too hard)
    res.redirect(307, redirectUrl);
});

app.post('/api/client/v2/global/login', proxy(TARGET_API_URL, {
    // 1. Ensure the path matches exactly on the target
    proxyReqPathResolver: function (req) {
        return '/api/client/v2/global/login';
    },

    // 2. Modify the body before sending
    proxyReqBodyDecorator: function(bodyContent, srcReq) {
        console.log('⚡ INTERCEPTING /login: Spoofing device to MOBILE/ANDROID...');

        try {
            // If body-parser is running, bodyContent might already be an Object.
            // If not, it might be a Buffer or String. We handle both cases:
            let body = bodyContent;

            if (Buffer.isBuffer(body)) {
                body = body.toString('utf8');
            }

            // Parse if it's a string
            if (typeof body === 'string') {
                body = JSON.parse(body);
            }
    console.log(JSON.stringify(body))
            // 3. Edit the fields
            body.device_class = "MOBILE";
            body.device_type = "MOBILE";
            body.device_os = "ANDROID";
            //body.device = "1458eeb6-2e1b-4da4-9ba1-8d3197f4810b";

            // 4. Return the new body as a JSON string
            console.log(JSON.stringify(body))
            return JSON.stringify(body);

        } catch (e) {
            console.error('❌ Failed to spoof login body:', e);
            return bodyContent; // Send original if something breaks
        }
    }
}));

// ==========================================
// 🔐 HYBRID LICENSE PROXY (Best of Both Worlds)
// ==========================================
app.post('/api/license', (req, res) => {
    const baseUrl = MAIN_API.replace(/\/$/, '');
    const path = req.originalUrl.startsWith('/') ? req.originalUrl : '/' + req.originalUrl;

    const redirectUrl = `${baseUrl}${path}`;
    res.redirect(307, redirectUrl);
});
// ==========================================
// 🚀 OPTIMIZATION: IMAGE REDIRECT
// ==========================================
// This sits BEFORE the proxy so images are 302 redirected immediately.
app.get('/api/client/v1/global/images/:imageId', (req, res) => {
    const baseUrl = TARGET_API_URL.replace(/\/$/, '');
    let cleanPath = req.originalUrl;
    if (cleanPath.startsWith('/api/api/')) {
        cleanPath = cleanPath.replace('/api/api/', '/api/');
    }
    if (!cleanPath.startsWith('/')) cleanPath = '/' + cleanPath;
    const redirectUrl = `${baseUrl}${cleanPath}`;
    res.redirect(307, redirectUrl);
});

app.get('/api/client/v1/global/content_device_concurrency/:whatever', (req, res) => res.status(202).send());

// ==========================================
// 📝 CHANNELS ROUTE
// ==========================================
app.get('/api/client/v2/default/users/:userid/channels', async (req, res) => {
    console.log('⚡unlocking channels.');
    const rawChannels =[{"id":11,"position":1,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,324,699,871],"order":0},{"id":12,"position":2,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,12,324,871],"order":1},{"id":13,"position":3,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,3,12,324,699],"order":2},{"id":14,"position":4,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,324,699,871],"order":3},{"id":15,"position":5,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,871,699,324],"order":4},{"id":16,"position":6,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,699,871,3,324],"order":5},{"id":3,"position":7,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,12,3],"order":6},{"id":5,"position":8,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,12,3],"order":7},{"id":6,"position":9,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,12,3],"order":8},{"id":7,"position":10,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,324,12,3,871],"order":9},{"id":17,"position":11,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12,3,699,871],"order":10},{"id":26,"position":12,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,3,12,324],"order":11},{"id":19,"position":13,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,871,699,324,3],"order":12},{"id":20,"position":14,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,324,12,3,699],"order":13},{"id":21,"position":15,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324,12],"order":14},{"id":22,"position":16,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,12,3,871,324],"order":15},{"id":23,"position":17,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,699,871,3,324],"order":16},{"id":24,"position":18,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,3,12,324],"order":17},{"id":25,"position":19,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,699,871,324,3],"order":18},{"id":18,"position":20,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,3],"order":19},{"id":27,"position":21,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,12,3],"order":20},{"id":28,"position":22,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,324,12,3,699],"order":21},{"id":29,"position":23,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324,12],"order":22},{"id":30,"position":24,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,871,699,324],"order":23},{"id":31,"position":25,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12,699,871,3],"order":24},{"id":32,"position":26,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,3,324,699,871],"order":25},{"id":33,"position":27,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,12,699,871],"order":26},{"id":34,"position":28,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,324,699,871],"order":27},{"id":35,"position":29,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,12,3],"order":28},{"id":36,"position":30,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324,3,871,699],"order":29},{"id":37,"position":31,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,12,324,871],"order":30},{"id":38,"position":32,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,3,12],"order":31},{"id":39,"position":33,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,324,12,3,871],"order":32},{"id":40,"position":34,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324],"order":33},{"id":41,"position":35,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,699,871,12],"order":34},{"id":42,"position":36,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,12,3,871],"order":35},{"id":43,"position":37,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,12,3],"order":36},{"id":44,"position":38,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324],"order":37},{"id":45,"position":39,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324],"order":38},{"id":46,"position":40,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,12,699,871],"order":39},{"id":47,"position":41,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,871,699,3,324],"order":40},{"id":48,"position":42,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,324,699,871],"order":41},{"id":49,"position":43,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871],"order":42},{"id":50,"position":44,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,3,699,324,12],"order":43},{"id":51,"position":45,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,12,324,871,699],"order":44},{"id":52,"position":46,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,3],"order":45},{"id":53,"position":47,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12],"order":46},{"id":54,"position":48,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12,3,871,699],"order":47},{"id":55,"position":49,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,871,324,12],"order":48},{"id":56,"position":50,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":49},{"id":57,"position":51,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324],"order":50},{"id":58,"position":52,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,3],"order":51},{"id":68,"position":53,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,871,699,324,3],"order":52},{"id":2086,"position":54,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,324,3,871],"order":53},{"id":61,"position":55,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,3,324],"order":54},{"id":62,"position":56,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,12],"order":55},{"id":63,"position":57,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324,3],"order":56},{"id":64,"position":58,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324,3],"order":57},{"id":2,"position":59,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,871,12,324],"order":58},{"id":60,"position":60,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,3,699,871,324],"order":59},{"id":67,"position":61,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324,12],"order":60},{"id":2126,"position":62,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,871,324],"order":61},{"id":70,"position":63,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,3,324],"order":62},{"id":71,"position":64,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324,871,699,3],"order":63},{"id":72,"position":65,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,3],"order":64},{"id":73,"position":66,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324,12],"order":65},{"id":74,"position":67,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,12],"order":66},{"id":75,"position":68,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":67},{"id":76,"position":69,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":68},{"id":77,"position":70,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":69},{"id":78,"position":71,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":70},{"id":79,"position":72,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,3,12],"order":71},{"id":80,"position":73,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,3,12,324,699],"order":72},{"id":81,"position":74,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,871],"order":73},{"id":82,"position":75,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12,3,699,871],"order":74},{"id":83,"position":76,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,699,871,12],"order":75},{"id":84,"position":77,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,12,3],"order":76},{"id":85,"position":78,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,871,12,3],"order":77},{"id":86,"position":79,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699,3],"order":78},{"id":87,"position":80,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,3],"order":79},{"id":88,"position":81,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,12,324,3],"order":80},{"id":89,"position":82,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324],"order":81},{"id":90,"position":83,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,12,324,871],"order":82},{"id":91,"position":84,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,324,3],"order":83},{"id":92,"position":85,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,324,12],"order":84},{"id":93,"position":86,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699],"order":85},{"id":94,"position":87,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,324,3],"order":86},{"id":95,"position":88,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,3,324,12],"order":87},{"id":96,"position":89,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,12,324,871],"order":88},{"id":97,"position":90,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,3,871],"order":89},{"id":98,"position":91,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[12,324,871,699],"order":90},{"id":99,"position":92,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,324,12,3,871],"order":91},{"id":100,"position":93,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,324,699],"order":92},{"id":101,"position":94,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,324],"order":93},{"id":102,"position":95,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871],"order":94},{"id":103,"position":96,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,12,324,871],"order":95},{"id":104,"position":97,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,324,12,3],"order":96},{"id":105,"position":98,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,699,871],"order":97},{"id":106,"position":99,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,3],"order":98},{"id":107,"position":100,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,324],"order":99},{"id":108,"position":101,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871],"order":100},{"id":109,"position":102,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,699,324,871],"order":101},{"id":110,"position":103,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,871,699],"order":102},{"id":111,"position":104,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,3,324,871],"order":103},{"id":112,"position":105,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,871,699],"order":104},{"id":113,"position":106,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871,324,3],"order":105},{"id":69,"position":107,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":106},{"id":59,"position":108,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,12],"order":107},{"id":8,"position":109,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":108},{"id":116,"position":110,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":109},{"id":117,"position":111,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3,871,699],"order":110},{"id":118,"position":112,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,699,871,324],"order":111},{"id":119,"position":113,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,324,3],"order":112},{"id":120,"position":114,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":113},{"id":121,"position":115,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":114},{"id":122,"position":116,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,699,871],"order":115},{"id":123,"position":117,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":116},{"id":124,"position":118,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":117},{"id":125,"position":119,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":118},{"id":126,"position":120,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":119},{"id":127,"position":121,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":120},{"id":128,"position":122,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,3],"order":121},{"id":129,"position":123,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,871,699,324],"order":122},{"id":130,"position":124,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324,699,871],"order":123},{"id":131,"position":125,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[3,324],"order":124},{"id":132,"position":126,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":true,"ts_duration":72,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699,3,324],"order":125},{"id":133,"position":127,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,871,699],"order":126},{"id":2085,"position":128,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871],"order":127},{"id":1831,"position":131,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,871],"order":128},{"id":1833,"position":133,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,871],"order":129},{"id":1834,"position":134,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[699,324,871],"order":130},{"id":1835,"position":135,"parental_hidden":false,"hidden":false,"purchased":"2035-06-01T00:00:00.000Z","timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[324,699,871],"order":131},{"id":1836,"position":136,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699],"order":132},{"id":1837,"position":137,"parental_hidden":false,"hidden":false,"purchased":null,"timeshiftable":false,"ts_duration":0,"recordable":false,"rec_quota":0,"favorited":false,"packages":[871,699],"order":133}];
    const unlockedChannels = rawChannels.map(channel => {
        return {
            ...channel, // Keeps all the original info (ID, name, etc.)
    packages: [3, 12, 324, 699, 871] // Overwrites the packages for everyone
        };
    });
    res.json({
        "status": "ok",
        "data": unlockedChannels
    });
});

// ==========================================
// 🚀 OPTIMIZATION 4: SMART CACHE LOGIC
// ==========================================
const onlyCacheSafeRoutes = (req, res) => {
    // Only cache GET requests
    if (req.method !== 'GET') return false;

    // ❌ NEVER CACHE:
    if (req.url.includes('/login')) return false;
    if (req.url.includes('/license')) return false;
    if (req.url.includes('/subscribe')) return false;
    if (req.url.includes('/refresh')) return false;

    // ❌ Don't cache binary files (images/video) - we redirect those anyway
    if (req.url.match(/\.(ts|mp4|m3u8|mpd|jpg|png)$/)) return false;

    // ✅ CACHE EVERYTHING ELSE (Channels, EPG, Movies)
    return true;
};

// ==========================================
// 5. MAIN PROXY (Optimized + Cached)
// ==========================================
const REGEX_API_URL = new RegExp("https://api.viu.lk", "g");
const REGEX_CDN_URL = new RegExp("https://bpcdn.dialog.lk", "g");
const REPLACEMENT_CDN = "https://bpc.viulk.xyz/api2";



// Apply Cache Middleware BEFORE the Proxy
app.use('/', cache('10 minutes', onlyCacheSafeRoutes), proxy(TARGET_API_URL, {
    https: true,
    agent: proxyAgent,
    parseReqBody: false,

    proxyReqOptDecorator: function(proxyReqOpts) {
        if (proxyReqOpts.headers['accept-encoding']) delete proxyReqOpts.headers['accept-encoding'];
        return proxyReqOpts;
    },

    userResHeaderDecorator(headers, userReq) {
        headers['access-control-allow-origin'] = userReq.headers.origin || '*';
        return headers;
    },

    userResDecorator: function(proxyRes, proxyResData, userReq) {
        const path = userReq.path;
        const contentType = (proxyRes.headers['content-type'] || '').toLowerCase();

        // 1. BINARY PASS-THROUGH
        if (
            contentType.includes('image') || contentType.includes('video') ||
            contentType.includes('audio') || contentType.includes('font')  ||
            contentType.includes('octet-stream') || path.match(/\.(ts|mp4|m3u8|mpd)$/)
        ) {
            return proxyResData;
        }

        // 2. TEXT PROCESSING
        let dataStr = proxyResData.toString('utf8');

        dataStr = dataStr.replace(REGEX_API_URL, MY_PROXY_URL);
        dataStr = dataStr.replace(REGEX_CDN_URL, REPLACEMENT_CDN);

        // 3. SMART MODIFICATION
        const modificationRule = RES_BODY_MODIFICATIONS.find(rule => {
            return (rule.pattern instanceof RegExp) ? rule.pattern.test(path) : rule.pattern === path;
        });

        if (!modificationRule) {
            return dataStr;
        }

        try {
            let dataJSON = JSON.parse(dataStr);
            dataJSON = modificationRule.modifier(dataJSON);
            return JSON.stringify(dataJSON);
        } catch (e) {
            return dataStr;
        }
    }
}));


http.createServer(app).listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 OPTIMIZED HTTP Proxy running at ${MY_PROXY_URL}`);
});
