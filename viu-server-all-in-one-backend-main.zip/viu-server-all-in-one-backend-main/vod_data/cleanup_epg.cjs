const fs = require('fs');

const inputFile = 'epg_programs.json';
const outputFile = 'epg_programs.json';

try {
  const rawData = fs.readFileSync(inputFile, 'utf8');
  const programs = JSON.parse(rawData);

  // Calculate the cutoff date (4 days ago from right now)
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - 4);

  const cleanedPrograms = programs.filter(program => {
    // If there's no end time, we probably want to keep it just in case
    if (!program.end) return true;

    // Look at when the show actually ENDS
    const endDate = new Date(program.end);

    // Keep it if the show ended LESS than 4 days ago, or is in the future
    return endDate >= cutoffDate;
  });

  fs.writeFileSync(outputFile, JSON.stringify(cleanedPrograms, null, 2), 'utf8');

  console.log('✅ Cleanup complete!');
  console.log(`Original program count: ${programs.length}`);
  console.log(`Cleaned program count:  ${cleanedPrograms.length}`);
  console.log(`Removed: ${programs.length - cleanedPrograms.length} outdated past broadcasts.`);

} catch (error) {
  console.error('❌ An error occurred:', error.message);
}
